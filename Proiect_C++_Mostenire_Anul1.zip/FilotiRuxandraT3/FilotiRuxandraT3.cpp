/*Problema 1
Se da urmatoarea ierarhie de clase:
Clasa Auto, clasa de baza, cu datele membre:
-marca string
-model string
-pret_final intreg
Clasa Motor, clasa copil, mosteneste clasa Auto si are datele membre
-combustibil, caracter, si poate fi : b/m/e
-autonomie intreg, doar pt electric
-pret intreg, pt varianta standard
Clasa Optiuni, clasa copil, mosteneste clasa Motor si are datele membre
-ac_automat, intreg. Aer conditionat automat si reprezinta pretul. Daca nu are, atunci pretul este 0
-sist_navigatie, intreg. Daca are sistem de navigatie, atunci semnifica pretul. Daca nu are, atunci pretul este 0
-capacitate_cil, intreg. Doar pt b/m si reprezinta capacitatea cilindrica a motorului pe b sau m. Pt electric e 0
-putere intreg. Puterea motorului
-roti17, intreg si reprezinta pretul pt roti de alte dimensiuni decat cele standard. Daca nu are, atunci valoarea este 0.
*/

#include <iostream>
#include <string>
#include <fstream>


using namespace std;

class Auto
{
    private:
    string marca,model;
    int pret_final;

    public:

     Auto(string marca, string model, int pret)
     {

        this -> marca = marca;
        this -> model = model;
        this -> pret_final = pret;
     }
     Auto(string marca, string model)
     {

        this -> marca = marca;
        this -> model = model;
        this -> pret_final = 0;
     }
    void setPret (int p)
    {
        pret_final = p;
    }

    int getPret()
    {
        return pret_final;
    }
    friend ostream& operator<<(ostream& out, const Auto& aut);
};
ostream& operator<<(ostream& out, const Auto& aut)
{
    out<<"Masina "<<aut.marca<<" model "<<aut.model<< " are pretul "<<aut.pret_final<<" euro.\n";
    return out;
}
class Motor: public Auto
{
private:
    char combustibil;
    int autonom, pret_std;
public:
    Motor(string marca, string model, int pret, char comb, int autonomie, int pret_std) : Auto(marca, model, pret)
    {

        this -> combustibil = comb;
        this -> autonom = autonomie;
        this ->pret_std = pret_std;

    }
    void setCombustibil (char c)
    {
        this -> combustibil=c;

    }
    char getCombustibil ()
    {
        return this-> combustibil;
    }
    friend ostream& operator<<(ostream& out, const Motor& mot);


};
ostream& operator<<(ostream& out, const Motor& mot)
    {
        cout<<(Auto)mot;
        out<<"Motorul este: ";
       if(mot.combustibil=='m')   out<<"motorina"<<'\n';
       else
       if(mot.combustibil=='b')    out<<"benzina"<<'\n';
       else                     out<<"electric"<<'\n';
       out<<"Autonomia este: "<<mot.autonom<<'\n';
       out<<"Pretul standard este: "<<mot.pret_std<<'\n';
        return out;
    }

class Optiuni: public Motor
{
private:
    int ac_automat;
    int sist_navigatie;
    int capacitate_cil;
    int putere;
    int roti17;
public:
    Optiuni (string marca, string model, int pret, char comb, int autonomie, int pret_std, int ac_automat, int sist_navigatie,
             int capacitate_cil, int putere, int roti17) : Motor(marca, model, pret, comb, autonomie, pret_std)

    {

        this -> ac_automat=ac_automat;
        this -> sist_navigatie=sist_navigatie;
        this -> capacitate_cil=capacitate_cil;
        this -> putere=putere;
        this -> roti17=roti17;
        int pf;
        pf = pret_std + ac_automat + sist_navigatie + roti17;
        this -> setPret(pf);
    }
     friend ostream& operator<<(ostream& out, const Optiuni& opt);


};
ostream& operator<<(ostream& out, const Optiuni& opt)
    {
        cout<<(Motor)opt;
        out<<"Optiuni: \n";
        out<<"\t Ac: "<< opt.ac_automat <<'\n';
        out<<"\t Sistnav: "<< opt.sist_navigatie <<'\n';
        out<<"\t Capcil: "<< opt.capacitate_cil <<'\n';
        out<<"\t Putere: "<< opt.putere <<'\n';
        out<<"\t R17: "<< opt.roti17 <<'\n';
        out<<'\n';
        return out;
    }


int main()
{

    Optiuni *opt1 = new Optiuni ("Volkswagen", "Caravan", 4000, 'e', 500, 2000, 1000, 200, 1900, 100, 400);
    cout<<*opt1;
    Optiuni *opt2 = new Optiuni ("BMW", "X6", 5000, 'm', 0, 3000, 2000, 300, 2000, 400, 600 );
    cout<<*opt2;
    Optiuni *opt3 = new Optiuni ("Skoda", "Fabio", 3000, 'b', 0, 1000, 500, 300, 1800, 100, 0);
    cout<<*opt3;
    Optiuni *opt4 = new Optiuni ("Mazda", "CX5", 7000, 'e', 600, 2300, 2000, 0, 200, 350, 120);
    cout<<*opt4;
    Optiuni *opt5 = new Optiuni ("Nissan", "Quashquai", 8000, 'm', 0, 4500, 3000, 300, 400, 450, 0);
    cout<<*opt5;
    return 0;

}




