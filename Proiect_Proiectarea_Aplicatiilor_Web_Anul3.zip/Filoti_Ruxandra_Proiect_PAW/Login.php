<?php
include_once 'config.php';

class Login{
    public static function login($user, $pass){
        $sql='select count(*) nr from login where user=:user and password=:pass';
        $arg[':user']=$user;
        $arg[':pass']=$pass;
        $nr=BDConnection::runSQL($sql, $arg);
        var_dump($nr);
        foreach($nr as $value){
            return $value['nr'];
        }
        return 0;

    }
}