<?php
include_once 'config.php';

class Pacient {



public function getPacienti() {
$sql = "select * from rf107.pacient";
BDConnection::generateTable(['cod_pacient', 'CNP', 'nume_pacient', 'pren_pacient', 'varsta_pacient', 'adresa_pacient'], BDConnection::runSQL($sql));
}

public function insertPacient($cod_pacient, $CNP, $nume_pacient, $pren_pacient, $varsta_pacient, $adresa_pacient) {

$sql = 'insert into rf107.pacient values(:cod, :CNP, :nume, :pren, :varsta, :adresa)';
$arg[':cod'] = $cod_pacient;
$arg[':CNP'] = $CNP;
$arg[':nume'] = $nume_pacient;
$arg[':pren'] = $pren_pacient;
$arg[':varsta'] = $varsta_pacient;
$arg[':adresa'] = $adresa_pacient;

BDConnection::runSQL($sql, $arg);
}

public function updatePacient($cod_pacient, $CNP, $nume_pacient, $pren_pacient, $varsta_pacient, $adresa_pacient) {

$sql = 'update rf107.pacient set CNP=:CNP, nume_pacient=:nume, pren_pacient=:pren, varsta_pacient=:varsta, adresa_pacient=:adresa '.
'where cod_pacient=:cod';
$arg[':cod'] = $cod_pacient;
$arg[':CNP'] = $CNP;
$arg[':nume'] = $nume_pacient;
$arg[':pren'] = $pren_pacient;
$arg[':varsta'] = $varsta_pacient;
$arg[':adresa'] = $adresa_pacient;

BDConnection::runSQL($sql, $arg);
}




public function deletePacient($cod_pacient) {
$sql = "delete from rf107.pacient where cod_pacient=:cod";
$arg[':cod'] = $cod_pacient;
BDConnection::runSQL($sql, $arg);
}





}
?>