<?php
include_once 'Pacient.php';
$pacient=new Pacient();

if(isset($_POST['delete']))  {
	if($_POST['pacientcode']!==''){
		$pacient->deletePacient($_POST['pacientcode']);
	}
	unset($_POST['delete']);
	}
else if(isset($_POST['update']))  {
	if($_POST['pacientcode']!==''){
		$pacient->updatePacient($_POST['pacientcode'], $_POST['cnp'], $_POST['firstname'], $_POST['lastname'], $_POST['age'], $_POST['address'] );
	}
	unset($_POST['update']);
}
else if(isset($_POST['insert']))  {
	if($_POST['pacientcode']!==''){
		$pacient->insertPacient($_POST['pacientcode'], $_POST['cnp'], $_POST['firstname'], $_POST['lastname'], $_POST['age'], $_POST['address'] );
	}
	unset($_POST['insert']);
}



?>
<!DOCTYPE html>
<html>
<head>
	<title>Cabinet Medical</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	
	<link rel="stylesheet/less" type="text/css" href="style.scss" />
	<script src="https://cdn.jsdelivr.net/npm/less@4" ></script>


</head>
<body>

<div>
	<?php
	
	?>	
</div>

<div>
	<form action="registration.php" method="post">
		<div class="container">
			
			<div class="row">
				<div class="col-sm-3">
					<h1>Inregistrare pacient</h1>
					<p>Completati cu informatiile corecte.</p>
					<hr class="mb-3">
                    <label for="pacientcode"><b>Id pacient</b></label>
					<input class="form-control" id="pacientcode" type="text" name="pacientcode" required placeholder="100">
                    
                    <label for="cnp"><b>CNP</b></label>
					<input class="form-control" id="cnp" type="text" name="cnp" required placeholder="5741212090041">
                    
                    <label for="firstname"><b>Nume</b></label>
					<input class="form-control" id="firstname" type="text" name="firstname" required placeholder="e.g. Popescu">

					<label for="lastname"><b>Prenume</b></label>
					<input class="form-control" id="lastname"  type="text" name="lastname" required placeholder="e.g. Alexandru">

                    <label for="age"><b>Varsta</b></label>
					<input class="form-control" id="age"  type="text" name="age" required placeholder="40">

					<label for="address"><b>Adresa pacient</b></label>
					<input class="form-control" id="address"  type="text" name="address" required placeholder="str. Brasoveni, nr. 28">
                    
                    

					<hr class="mb-3">
					<input class="btn btn-primary" type="submit" id="insert" name="insert" value="insert">
					<input class="btn btn-primary" type="submit" id="update" name="update" value="update">
					<input class="btn btn-primary" type="submit" id="delete" name="delete" value="delete">
				</div>
			</div>
		</div>
	</form>
</div>
<br>
<?php
$pacient->getPacienti();

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

</body>
</html>