<?php
include_once 'Login.php';
if(isset($_POST['login'])){
    if(Login::login($_POST['user'],$_POST['pass'])>0){
        header('Location:registration.php');
    
        
    }
    else echo 'gresit';
}
?>
<html>
    <head>
        
    </head>
    <body>
        <form action="Loginform.php" method="post">
<br>
        <input type="text" name="user" placeholder="user"><br>
        <input type="password" name="pass" placeholder="password"><br>
       
        <input class="button" type="submit" name="login" value="Log In" id="login">
     
        </form>
    </body>
</html>