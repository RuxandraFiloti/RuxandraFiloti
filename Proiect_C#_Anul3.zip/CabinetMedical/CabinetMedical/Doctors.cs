﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CabinetMedical
{
    public partial class Doctors : Form
    {
        public Doctors()
        {
            InitializeComponent();
            DisplayDoc();
        }

        private void Doctors_Load(object sender, EventArgs e)
        {

        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\bella\Documents\CabinetMedicalDB.mdf;Integrated Security=True;Connect Timeout=30");

        private void DisplayDoc()
        {
            Con.Open();
            string Query = "select * from MedicTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            Con.Close();



        }
        private void Clear()
        {
            textBox1.Text = "";
            textBox5.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox2.SelectedIndex = 0;
            textBox4.Text = "";
            Key = 0;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox5.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox2.SelectedIndex == -1 || textBox4.Text == "") 
            {
                MessageBox.Show("Informatia nu exista");
            }
             else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into MedicTbl(numeMedic, sexMedic, adresaMedic, telefonMedic, specializareMedic, parolaMedic)values(@NM, @SM, @AM, @TM, @SD, @PM)", Con);
                    cmd.Parameters.AddWithValue("@NM", textBox1.Text);
                    cmd.Parameters.AddWithValue("@SM", textBox5.Text);
                    cmd.Parameters.AddWithValue("@AM", textBox2.Text);
                    cmd.Parameters.AddWithValue("@TM", textBox3.Text);
                    cmd.Parameters.AddWithValue("@SD", comboBox2.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@PM", textBox4.Text);
                   

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Medic adaugat");
                    Con.Close();
                    DisplayDoc();
                    Clear();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox5.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox2.SelectedIndex == -1 || textBox4.Text == "") 
            {
                MessageBox.Show("Informatia nu exista");
            }
             else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("update MedicTbl set numeMedic=@NM, sexMedic=@SM, adresaMedic=@AM, telefonMedic=@TM, specializareMedic=@SD, parolaMedic=@PM where idMedic=@MKey", Con);
                    cmd.Parameters.AddWithValue("@NM", textBox1.Text);
                    cmd.Parameters.AddWithValue("@SM", textBox5.Text);
                    cmd.Parameters.AddWithValue("@AM", textBox2.Text);
                    cmd.Parameters.AddWithValue("@TM", textBox3.Text);
                    cmd.Parameters.AddWithValue("@SD", comboBox2.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@PM", textBox4.Text);
                    cmd.Parameters.AddWithValue("@MKey", textBox6.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Medicul a fost modificat");
                    Con.Close();
                    DisplayDoc();
                    Clear();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
                    try
                    {
                        Con.Open();
                        SqlCommand cmd = new SqlCommand("Delete from MedicTbl where idMedic=@MKey", Con);
                        cmd.Parameters.AddWithValue("@MKey", textBox6.Text);
                        cmd.ExecuteNonQuery();
                    MessageBox.Show("Medicul a fost sters");
                        Con.Close();
                        DisplayDoc();
                        Clear();

                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                
                }
            
        
        int Key = 0;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            comboBox2.SelectedItem = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            if (textBox1.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.a.Show();
        }
    }
}
