﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CabinetMedical
{
    public partial class Pacients : Form
    {
        public Pacients()
        {
            InitializeComponent();
            DisplayPac();
            Clear();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\bella\Documents\CabinetMedicalDB.mdf;Integrated Security=True;Connect Timeout=30");


        private void PDelete_Click(object sender, EventArgs e)
        {
            
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Delete from PacientTbl where idPacient=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PKey", textBox7.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Pacientul a fost sters");
                    Con.Close();
                    DisplayPac();
                    Clear();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        
    

        private void PUpdate_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox6.Text == "" || textBox4.Text == "" || textBox2.Text == ""
               || textBox3.Text == "" || textBox5.Text == "") 
            {
                MessageBox.Show("Informatia nu exista");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("update PacientTbl set  numePacient=@NP, sex=@S, dataNasterii=@DN, adresaPacient=@AP, telefonPacient=@TP, diagnosticPacient=@DP where idPacient=@PKey", Con);
                    cmd.Parameters.AddWithValue("@NP", textBox1.Text);
                    cmd.Parameters.AddWithValue("@S", textBox6.Text);
                    cmd.Parameters.AddWithValue("@DN", textBox4.Text);
                    cmd.Parameters.AddWithValue("@AP", textBox2.Text);
                    cmd.Parameters.AddWithValue("@TP", textBox3.Text);
                    cmd.Parameters.AddWithValue("@DP", textBox5.Text);
                    cmd.Parameters.AddWithValue("@PKey", textBox7.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Coloana a fost modificata");
                    Con.Close();
                    DisplayPac();
                    Clear();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void DisplayPac()
        {
            Con.Open();
            string Query = "select * from PacientTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            PacientDGV.DataSource = ds.Tables[0];
            Con.Close();
            
            

        }
        private void PAdd_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox6.Text == "" || textBox4.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "") 
            {
                MessageBox.Show("Informatia nu exista");
            }
             else
            {
                try
                { Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into PacientTbl(numePacient, sex, dataNasterii, adresaPacient, telefonPacient, diagnosticPacient)values(@NP, @S, @DN, @AP, @TP, @DP)", Con);
                    cmd.Parameters.AddWithValue("@NP", textBox1.Text);
                    cmd.Parameters.AddWithValue("@S", textBox6.Text);
                    cmd.Parameters.AddWithValue("@DN", textBox4.Text);
                    cmd.Parameters.AddWithValue("@AP", textBox2.Text);
                    cmd.Parameters.AddWithValue("@TP", textBox3.Text);
                    cmd.Parameters.AddWithValue("@DP", textBox5.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Pacient adaugat");
                    Con.Close();
                    DisplayPac();
                    Clear();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            
            }
        

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        int Key = 0;

        private void PacientDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = PacientDGV.SelectedRows[0].Cells[1].Value.ToString();
            textBox6.Text = PacientDGV.SelectedRows[0].Cells[2].Value.ToString();
            textBox2.Text = PacientDGV.SelectedRows[0].Cells[3].Value.ToString();
            textBox3.Text = PacientDGV.SelectedRows[0].Cells[4].Value.ToString();
            textBox4.Text = PacientDGV.SelectedRows[0].Cells[5].Value.ToString();
            textBox5.Text = PacientDGV.SelectedRows[0].Cells[6].Value.ToString();
            if(textBox1.Text == "")
            {
                Key = 0; 
            }
            else
            {
                Key = Convert.ToInt32(PacientDGV.SelectedRows[0].Cells[0].Value.ToString());

            }

        }
        private void Clear()
        {
            textBox1.Text = "";
            textBox6.Text = "";
            textBox2.Text = "";
            textBox3.Text= "";
            textBox4.Text = "";
            textBox5.Text = "";
            Key = 0;





        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.a.Show();                        
        }
    }
}
