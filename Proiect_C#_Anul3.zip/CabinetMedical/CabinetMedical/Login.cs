﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CabinetMedical
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            textBox1.Text = "";
            textBox2.Text = "";
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\bella\Documents\CabinetMedicalDB.mdf;Integrated Security=True;Connect Timeout=30");
        public static string Role;
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Selecteaza persoana");
            }else if (comboBox1.SelectedIndex == 0)
            {if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("Introduceti username si parola Admin");
                }
                else if (textBox1.Text == "Admin" || textBox2.Text == "parola")
                {
                    Role = "Admin";
                    Doctors Obj = new Doctors();
                    Obj.Show();
                    this.Hide();
                }else
                {
                    MessageBox.Show("Ati introdus gresit username-ul si parola admin");
                }

            }else if(comboBox1.SelectedIndex==1)
            {
                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("Introduceti username si parola Medic");
                }
                else 
                {
                    Con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from MedicTbl where numeMedic='" + textBox1.Text + "' and parolaMedic='" + textBox2.Text + "'", Con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        Role = "Medic";
                        Pacients Obj = new Pacients();
                        Obj.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Medicul nu a fost gasit");
                    }
                    Con.Close();

                }
                
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
