/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class Motosapa extends Aparat{
    private String culoare;
	private float putereMotor, capacitateCilindrica;
	private int nrViteze;
	private double latimeLucruMax;
	
	
	public Motosapa (String culoare, float putereMotor,float capacitateCilindrica, 
		int nrViteze,double latimeLucruMax, String denumire, float lungime,float latime,float inaltime, float greutate,
		 int nrFunctii, int putere,int consum, double pret){
			
			
			super(denumire, lungime,latime, inaltime,greutate,nrFunctii, putere,consum,pret);
				
				
			this.culoare = culoare;
			this.putereMotor = putereMotor;
			this.capacitateCilindrica = capacitateCilindrica;
			this.nrViteze = nrViteze;
			this.latimeLucruMax = latimeLucruMax;
			
		}
		
		public Motosapa (Motosapa P){
			super(P);
			this.culoare = P.culoare;
			this.putereMotor = P.putereMotor;
			this.capacitateCilindrica = P.capacitateCilindrica;
			this.nrViteze = P.nrViteze;
			this.latimeLucruMax = P.latimeLucruMax;
		}
		
		public Motosapa(){
			
			super();
			this.culoare = "" ;
		 	this.putereMotor= 0 ;
			
			this.capacitateCilindrica =0 ;
			this.nrViteze =0 ;
			this.latimeLucruMax =  0;
			
			
		}
		
			
	//getter

	public String getCuloare (){
		return culoare;
	}
	//setter
	public void setCuloare(String nouCuloare){
		this.culoare  = nouCuloare;
	}
	public float getPutereMotor(){
		return putereMotor;
	}
	public void setPutereMotor (float nouPutereMotor){
		this.putereMotor = nouPutereMotor;
	}
	public int getNrViteze(){
 		return nrViteze;
	}
	public void setNrViteze (int nouNrViteze){
		this.nrViteze = nouNrViteze;
	}
	public double getLatimeLucruMax (){
		return latimeLucruMax;
	}
	public void setLAtimeLucruMax (double nouLatimeLucruMax){
		this.latimeLucruMax = nouLatimeLucruMax;
	}
	public float getCapacitateCilindrica (){
		return capacitateCilindrica;
	}
	public void setCapacitateCilindrica (float nouCapacitateCilindrica){
		this.capacitateCilindrica = nouCapacitateCilindrica;
	}
		
	
	public String toString(){
	 return super.toString() +"\n\tCuloare:" + culoare + "\n\tPutere motor:" + 
	 	putereMotor + "\n\tCapacitate cilindrica:" + capacitateCilindrica + "\n\tNumar viteze:" + 
	 		nrViteze +"\n\tLatime lucru max:"+ latimeLucruMax;
}

        public class SortDen implements Comparator<Motosapa>{
		public int compare(Motosapa a,Motosapa b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	
        public class SortPret implements Comparator<Motosapa>{
	 		public int compare(Motosapa a,Motosapa b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static Motosapa [] sorT(Motosapa[] a,int op) {
		Motosapa[] b=new Motosapa[a.length];
                b=a.clone();
                if(op==1)
                {Arrays.sort(b, new Motosapa().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new Motosapa().new SortPret());
		                       return b; }
           return b;    
	}
   
        
}
