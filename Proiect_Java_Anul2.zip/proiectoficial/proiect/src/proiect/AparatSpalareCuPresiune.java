/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class AparatSpalareCuPresiune extends Aparat{
    private String culoare;
   private int debit, presiune, nivelZgomot;
   public AparatSpalareCuPresiune()
   {
       super();
       this.setDenumire("AparatSpalareCuPresiune");
       this.culoare="rosu";
       this.debit=380;
       this.presiune=140;
       this.nivelZgomot=93;
       
       
   }
   public AparatSpalareCuPresiune(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,int putere, int consum, double pret, String culoare, int debit, int presiune, int nivelZgomot){
   
       super(denumire,lungime,latime, inaltime, greutate,nrFunctii, putere, consum, pret);
       this.culoare=culoare;
       this.debit=debit;
       this.presiune=presiune;
       this.nivelZgomot=nivelZgomot;
       
   }
   public AparatSpalareCuPresiune(AparatSpalareCuPresiune F){
       super(F);
       this.culoare=F.culoare;
       this.debit=F.debit;
       this.presiune=F.presiune;
       this.nivelZgomot=F.nivelZgomot;
   }
    
   public String getCuloare(){
       return culoare;
   }
   public void setCuloare(String culoare){
       this.culoare=culoare;
   }
   public int getDebit(){
       return debit;
     }
   public void setDebit(int debit){
       this.debit=debit;
   }
   public int getPresiune(){
       return presiune;
   }
   public void setPresiune(int presiune){
       this.presiune=presiune;
   }
   public int getNivelZgomot(){
       return nivelZgomot;
   }
   public void setNivelZgomot(int nivelZgomot){
       this.nivelZgomot=nivelZgomot;
   }
   public String toString(){
       return super.toString() +"\n\tculoare:" + culoare + "\n\tdebit:" + debit + "\n\tpresiune:" + presiune + "\n\tnivelZgomot:" + nivelZgomot;
   }
   
   
    public class SortDen implements Comparator<AparatSpalareCuPresiune>{
		public int compare(AparatSpalareCuPresiune a,AparatSpalareCuPresiune b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<AparatSpalareCuPresiune>{
	 		public int compare(AparatSpalareCuPresiune a,AparatSpalareCuPresiune b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static AparatSpalareCuPresiune [] sorT(AparatSpalareCuPresiune[] a,int op) {
		AparatSpalareCuPresiune[] b=new AparatSpalareCuPresiune[a.length];
                b=a.clone();
                if(op==1)
                {Arrays.sort(b, new AparatSpalareCuPresiune().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new AparatSpalareCuPresiune().new SortPret());
		                       return b; }
           return b;    
	}
    
}
