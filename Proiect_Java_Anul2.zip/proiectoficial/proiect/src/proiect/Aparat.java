package proiect;

import java.util.Arrays;
import java.util.Comparator;

public class Aparat {
	 private String denumire;
		private float lungime,latime,inaltime, greutate;
		private int nrFunctii, putere, consum;
		private double pret;
		//constructor fara parametri
		public Aparat() {
			denumire="Aparat";
			lungime=60.0f;
			latime=60.0f;
			inaltime=60.0f;
			greutate=55.3f;
			nrFunctii=2;
			putere=100;
			consum=90;
			pret=500.99;
		}
		//constructor cu parametri
		public Aparat(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,
				int putere, int consum, double pret) {
			
			this.denumire = denumire;
			this.lungime = lungime;
			this.latime = latime;
			this.inaltime = inaltime;
			this.greutate = greutate;
			this.nrFunctii = nrFunctii;
			this.putere = putere;
			this.consum = consum;
			this.pret = pret;
		}
	//constructor de copiere
		public Aparat(Aparat A) {
			
			this.denumire = A.denumire;
			this.lungime = A.lungime;
			this.latime = A.latime;
			this.inaltime= A.inaltime;
			this.greutate =A. greutate;
			this.nrFunctii =A. nrFunctii;
			this.putere = A.putere;
			this.consum = A.consum;
			this.pret = A.pret;
		}
		
		public String getDenumire() {
			return denumire;
		}

		public void setDenumire(String denumire) {
			this.denumire = denumire;
		}

		public float getLungime() {
			return lungime;
		}

		public void setLungime(float lungime) {
			this.lungime = lungime;
		}

		public float getLatime() {
			return latime;
		}

		public void setLatime(float latime) {
			this.latime = latime;
		}

		public float getInaltime() {
			return inaltime;
		}

		public void setInaltime(float inaltime) {
			this.inaltime = inaltime;
		}

		public float getGreutate() {
			return greutate;
		}

		public void setGreutate(float greutate) {
			this.greutate = greutate;
		}

		public int getNrFunctii() {
			return nrFunctii;
		}

		public void setNrFunctii(int nrFunctii) {
			this.nrFunctii = nrFunctii;
		}

		public int getPutere() {
			return putere;
		}

		public void setPutere(int putere) {
			this.putere = putere;
		}

		public int getConsum() {
			return consum;
		}

		public void setConsum(int consum) {
			this.consum = consum;
		}

		public double getPret() {
			return pret;
		}

		public void setPret(double pret) {
			this.pret = pret;
		}
	//metoda toString clasa parinte(adaugare \t)
		public String toString() {
			return "\ndenumire : " + denumire + "\n\tlungime : " + lungime + "\n\tlatime :" + latime + "\n\tinaltime : " + inaltime
					+ "\n\tgreutate : " + greutate + "\n\tnrFunctii : " + nrFunctii + "\n\tputere : " + putere + "\n\tconsum : " + consum
					+ "\n\tpret : " + pret;
		}

    public class SortDen implements Comparator<Aparat>{
		public int compare(Aparat a,Aparat b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<Aparat>{
	 		public int compare(Aparat a,Aparat b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static Aparat[] sorT(Aparat[] a,int op) {
		Aparat[] b=new Aparat[a.length];
                b=a.clone();
		//System.arraycopy(a, 0, b, 0, b.length);
                if(op==1)
                {
                    Arrays.sort(b, new Aparat().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new Aparat().new SortPret());
		                       return b; }
           return b;    
	}
}
