/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class Suflanta extends Aparat{
    private String culoare;
    private String model;
    private int debitAer, vitezaAer, nivelZgomot;
    
    public Suflanta() {
        super();
        this.setDenumire("Suflanta");
        this.culoare="gri";
        this.model="Skil 0792";
        this.debitAer=13;
        this.vitezaAer=270;
        this.nivelZgomot=100;
        
    }
    public Suflanta(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii, 
            int putere, int consum, double pret, String culoare, String model, int debitAer, int vitezaAer, int nivelZgomot){
        super(denumire,lungime, latime, inaltime, greutate, nrFunctii, putere, consum, pret);
        this.culoare=culoare;
        this.model=model;
        this.debitAer=debitAer;
        this.vitezaAer=vitezaAer;
        this.nivelZgomot=nivelZgomot;
    }
    public Suflanta(Suflanta F){
        super(F);
        this.culoare=F.culoare;
        this.model=F.model;
        this.debitAer=F.debitAer;
        this.vitezaAer=F.vitezaAer;
        this.nivelZgomot=F.nivelZgomot;
    }
    public String getCuloare(){
        return culoare;
        
    }
    public void setCuloare(String culoare){
        this.culoare=culoare;
    }
    public String getModel(){
        return model;
       
    }
    public void setModel(String model){
        this.model=model;
    }
    public int getDebitAer(){
        return debitAer;
    }
    public void setDebitAer(int debitAer){
        this.debitAer=debitAer;
    }
    public int getVitezaAer(){
        return vitezaAer;
    }
    public void setVitezaAer(int vitezaAer){
        this.vitezaAer=vitezaAer;
    }
    public int getNivelZgomot(){
        return nivelZgomot; 
    }
    public void setNivelZgomot(int nivelZgomot){
        this.nivelZgomot=nivelZgomot;
    }
    public String toString() {
	return super.toString()+"\n\tculoare : "+culoare+"\n\tmodel : "+model+"\n\tdebitAer : "+debitAer+"\n\tvitezaAer : "+vitezaAer+"\n\tnivelZgomot : "+nivelZgomot;
    }
    
     public class SortDen implements Comparator<Suflanta>{
		public int compare(Suflanta a,Suflanta b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<Suflanta>{
	 		public int compare(Suflanta a,Suflanta b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static Suflanta[] sorT(Suflanta[] a,int op) {
		Suflanta[] b=new Suflanta[a.length];
                b=a.clone();
                if(op==1)
                {Arrays.sort(b, new Suflanta().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new Suflanta().new SortPret());
		                       return b; }
           return b;    
	}
    
    
}
