/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class AparatCuratatPardoseli extends Aparat{
     private int diametru,lungimeCablu, capacitateRezervor;
    private String culoare;
   private double vitezaRotatie;


    public AparatCuratatPardoseli(){
        super();
        this.setDenumire("AparatCuratatPardoseli");
        this.diametru=70;
        this.lungimeCablu=5;
        this.capacitateRezervor=10;
        this.culoare="negru";
        this.vitezaRotatie=250;
    }
    public AparatCuratatPardoseli(String denumire,float lungime,float latime,float inaltime,float greutate,int nrFunctii,int putere,int consum,double pret,
                                  int diametru,int lungimeCablu,int capacitateRezervor,String culoare, double vitezaRotatie ){
        super(denumire,lungime,latime,inaltime,greutate,nrFunctii,putere,consum,pret);
        this.capacitateRezervor=capacitateRezervor;
        this.culoare=culoare;
        this.diametru=diametru;
        this.lungimeCablu=lungimeCablu;
        this.vitezaRotatie=vitezaRotatie;
    }

    public AparatCuratatPardoseli(AparatCuratatPardoseli A){
        super(A);
        this.capacitateRezervor=A.capacitateRezervor;
        this.culoare=A.culoare;
        this.diametru=A.diametru;
        this.lungimeCablu=A.lungimeCablu;
        this.vitezaRotatie=A.vitezaRotatie;

    }
    public final int  getDiametru(){
        return diametru;
    }
    public void setDiametru(int diametru){
        this.diametru=diametru;
    }

    public final int  getLungimeCablu(){
        return lungimeCablu;
    }
    public void setLungimeCablu(int lungimeCablu){
        this.lungimeCablu=lungimeCablu;
    }


    public final int getCapacitateRezervor(){
        return capacitateRezervor;
    }
    public void setCapacitateRezervor(int capacitateRezervor){
        this.capacitateRezervor=capacitateRezervor;
    }


    public final String getCuloare(){
        return culoare;
    }
    public void setCuloare(String culoare){
        this.culoare=culoare;
    }


    public final double getVitezaRotatie(){
        return vitezaRotatie;
    }
    public void setAccesorii(double vitezaRotatie){
        this.vitezaRotatie=vitezaRotatie;
    }


    public String toString(){
        return super.toString() + "\n\tdiametru : " + diametru + "\n\tlungimeCablu : " + lungimeCablu +  "\n\tcapacitateRezervor : " + "\n\tculoare : "+culoare+"\n\tvitezaRotatie : "+vitezaRotatie;
    }
    
      public class SortDen implements Comparator<AparatCuratatPardoseli> {
        public int compare(AparatCuratatPardoseli a, AparatCuratatPardoseli b) {
            return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
        }
    }

    public class SortPret implements Comparator<AparatCuratatPardoseli> {
        public int compare(AparatCuratatPardoseli a, AparatCuratatPardoseli b) {
            return (int)(a.getPret() - b.getPret());
        }
    }

    public static AparatCuratatPardoseli [] sorT(AparatCuratatPardoseli[] a, int op){
        AparatCuratatPardoseli[] b=new AparatCuratatPardoseli[a.length];
        b=a.clone();
        if(op==1){
            Arrays.sort(b,new AparatCuratatPardoseli().new SortDen());
            return b;
        }
        if (op==2){
            Arrays.sort(b, new AparatCuratatPardoseli().new SortPret());
            return b;
        }
        return b;
    }
}
