/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class Trimmer extends Aparat{
   private String culoare,tipMotor;
   private  int vitezaMaxima, capacitate;


    public Trimmer (String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,
                    int putere, int consum, double pret,String culoare,String tipMotor,int vitezaMaxima,int capacitate){
        super(denumire, lungime,latime, inaltime,greutate,nrFunctii, putere,consum,pret);

        this.culoare = culoare;
        this.tipMotor = tipMotor;
        this.vitezaMaxima = vitezaMaxima;
        this.capacitate = capacitate;

    }
    public Trimmer(Trimmer B){
        super(B);
        this.culoare = B.culoare;
        this.tipMotor=B.tipMotor;
        this.vitezaMaxima=B.vitezaMaxima;
        this.capacitate=B.capacitate;
    }
    public Trimmer(){

        super();
        this.culoare = "" ;
        this.tipMotor= "" ;
        this.vitezaMaxima =0 ;
        this.capacitate =0 ;
    }
    public String getCuloare (){

        return culoare;
    }

    public void setCuloare(String nouaCuloare){

        this.culoare=nouaCuloare;
    }
    public String getTipMotor(){
        return tipMotor;
    }
    public void setTipMotor(String nouTipMotor){
        this.tipMotor=nouTipMotor;
    }

    public int getVitezaMaxima(){
        return vitezaMaxima;
    }
    public void setVitezaMaxima(int nouaVitezaMaxima) {
        this.vitezaMaxima = nouaVitezaMaxima;
    }
    public int getCapacitate(){
        return capacitate;
    }
    public void setCapacitate(int nouaCapacitate){
        this.capacitate=nouaCapacitate;
    }

public String toString(){
return super.toString() + "\n\tculoare : "+ culoare + "\n\ttipMotor :" + tipMotor + "\n\tvitezaMaxima:"+ vitezaMaxima + "\n\tcapacitate : " + capacitate;
}

 public class SortDen implements Comparator<Trimmer>{
        public int compare(Trimmer a,Trimmer b) {
            return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());}}

            public class SortPret implements Comparator<Trimmer>{
                public int compare(Trimmer a,Trimmer b)
                {
                    return (int)(a.getPret()-b.getPret());
                }}
                public static Trimmer[] sorT(Trimmer[] a,int op) {
                    Trimmer[] b=new Trimmer[a.length];
                    b=a.clone();
                    if(op==1)
                    {Arrays.sort(b, new Trimmer().new SortDen());
                        return b; }
                    if(op==2)
                    {Arrays.sort(b, new Trimmer().new SortPret());
                        return b; }
                    return b;    }

}
