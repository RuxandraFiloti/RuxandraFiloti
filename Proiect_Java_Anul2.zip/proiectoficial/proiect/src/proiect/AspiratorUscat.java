package proiect;

import java.util.Arrays;
import java.util.Comparator;

public class AspiratorUscat extends Aparat{
	
	  private String tipDisplay;
	  private boolean AI, WIFI;
	 	//constructor fara parametrii(mostenire)
	 public AspiratorUscat()
	 {
	 	super();
	 	this.setDenumire("AspiratorUscat");
	 	this.tipDisplay="LED";
	 	this.AI=true;
	 	this.WIFI=true;
	 	
	 	}
	 //constructor cu parametrii(mostenire)
	 public AspiratorUscat(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,
	 		int putere, int consum, double pret,String tipDisplay,boolean AI, boolean WIFI)
	 {
	 	super(denumire,lungime,latime,inaltime,greutate,nrFunctii,putere,consum,pret);
	 	this.tipDisplay=tipDisplay;
	 	this.AI=AI;
	 	this.WIFI=WIFI;
	 	
	 }
	 //constructor copiere(mostenire)

	 public AspiratorUscat(AspiratorUscat A) {
	 	super(A);//modificare apel constructor de copiere
	 	this.tipDisplay=A.tipDisplay;
	 	this.AI=A.AI;
	 	this.WIFI=A.WIFI;
	 }

	 public String getTipDisplay() {
	 return tipDisplay;
	 }

	 public void setTipDisplay(String tipDisplay)
	 {this.tipDisplay=tipDisplay;}

	 public boolean getAI(){
	 	return AI;
	 }

	 public void setAI(boolean AI){
	 	this.AI=AI;	
	 }

	 public boolean getWIFI() {
	 	return WIFI;
	 }

	 public void setWIFI(boolean WIFI) {
	 	this.WIFI=WIFI;
	 }
	 //metoda toString mostenire de la clasa Aparat(adaugare \t)
	 public String toString() {
	 	
	 	return super.toString()+"\n\ttipDisplay : "+tipDisplay+"\n\tAI : "+AI+"\n\tWIFI : "+WIFI;
	 }
        public class SortDen implements Comparator<AspiratorUscat>{
		public int compare(AspiratorUscat a,AspiratorUscat b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<AspiratorUscat>{
	 		public int compare(AspiratorUscat a,AspiratorUscat b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static AspiratorUscat[] sorT(AspiratorUscat[] a,int op) {
		AspiratorUscat[] b=new AspiratorUscat[a.length];
                b=a.clone();
		//System.arraycopy(a, 0, b, 0, b.length);
                if(op==1)
                {Arrays.sort(b, new AspiratorUscat().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new AspiratorUscat().new SortPret());
		                       return b; }
           return b;    
	}
}
