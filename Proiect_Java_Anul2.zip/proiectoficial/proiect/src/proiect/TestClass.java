package proiect;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.LineNumberReader;

public class TestClass {
         
	 Aparat a,d,q;
         Aparat[] vAparat;
         Aparat[] vAparate;
	 AspiratorUscat b,e,f,y;
	 AspiratorUmed c,g,h,x;
	 AspiratorUmed[] vAspiratorUmed;
	 AspiratorUscat[] vAspiratorUscat;
         
         AparatSpalareCuPresiune ascp1, ascp2, ascp3;
         Suflanta s1, s2,s3;
         AparatSpalareCuPresiune[] vAparatSpalareCuPresiune;     
         Suflanta[] vSuflanta;            
        
         MasinaTunsIarba mt1, mt2, mt3;
	 Motosapa m1, m2,m3;
         MasinaTunsIarba[] vMasinaTunsIarba;
         Motosapa[] vMotosapa;
         
         Drujba d1,d2,d3;
         Trimmer t1,t2,t3;
         Trimmer[] vTrimmer;
         Drujba[] vDrujba;

         AparatCuratatPardoseli C, D, G;
         AparatCuratatGeamuri E, R, P;
         AparatCuratatPardoseli vectAparatCuratatPardoseli[];
         AparatCuratatGeamuri vectAparatCuratatGeamuri[];

	File F;
        FileWriter fin;
        LineNumberReader br;
        FileReader fr;
	  TestClass() {
			//minim 3 instante din fiecare clasa
       			 a=new Aparat("acdg",12,13,15,40,5,300,67,1000);
			 d=new Aparat(a); 
			 q=new Aparat();
                         vAparat=new Aparat[]{q,d,a};    
        
			 b= new AspiratorUscat("bbbb",16,13,25,40,5,300,67,600,"LCD",true,false);
			 e= new AspiratorUscat(b);
			 f=new AspiratorUscat();
                         y= new AspiratorUscat("axsd",16,13,25,40,5,300,67,1200,"LCD",true,false);
			 c=new AspiratorUmed("ccccc",13,14,15,40,5,200,567,500.76,4,12,5,true,false,false);
                         x=new AspiratorUmed("aaaa",13,14,15,40,5,200,567,10000,4,12,5,true,false,false);
			 g=new AspiratorUmed(c);
			 h=new AspiratorUmed();
	                 vAspiratorUscat=new AspiratorUscat[]{b,y,e,f};
	                 vAspiratorUmed=new AspiratorUmed[]{c,x,g,h};
                        
                         ascp1= new AparatSpalareCuPresiune("ggg", 12, 13, 15, 40, 5, 300, 67, 600, "rosu", 380, 140, 93);    
                         ascp2=new AparatSpalareCuPresiune(ascp1);        
                         ascp3=new AparatSpalareCuPresiune();         
                         s1= new Suflanta("ppp", 12, 13, 15, 40, 5, 300, 67, 600, "gri", "Skil 0792", 13, 270, 100); 
                         s2=new Suflanta(s1);   
                         s3=new Suflanta();     
                         vAparatSpalareCuPresiune=new AparatSpalareCuPresiune[] {ascp1, ascp2, ascp3};  
                         vSuflanta=new Suflanta[] {s1, s2, s3}; 
                         
                         mt1 = new MasinaTunsIarba("Benzina",46,20,30,2,"Makita",210,1102,1010,50,4,7,1,1798);
                         mt2 = new MasinaTunsIarba();
                         mt3 = new MasinaTunsIarba(mt1);
                         m1 = new Motosapa("Multicolor",7,208,4,83,"RurisDAC",70,100,50,80,4,7,1,1729);
                         m2 = new Motosapa();
		         m3 = new Motosapa(m1);
	                 vMasinaTunsIarba=new MasinaTunsIarba[]{mt1,mt2,mt3};
	                 vMotosapa=new Motosapa[]{m1,m2,m3};
                         
                         d1= new Drujba("bbbb",16,13,25,40,5,300,67,600,"Benzina","Sfoara","Multicolor");
                         d2= new Drujba(d1);
                         d3=new Drujba();
                         t1=new Trimmer("ccccc",13,14,15,40,5,200,567,600,"rosu","electric",100,50);
                         t2=new Trimmer(t1);
                         t3=new Trimmer();
                         vDrujba=new Drujba[]{d1,d2,d3};
                         vTrimmer=new Trimmer[]{t1,t2,t3};
                         
                         C = new AparatCuratatPardoseli("bosch", 12, 13, 14, 23, 4, 123, 33, 660, 70, 5, 10, "negru", 250);
                         D = new AparatCuratatPardoseli();
                         G = new AparatCuratatPardoseli();
                         E = new AparatCuratatGeamuri();
                         R = new AparatCuratatGeamuri();
                         P = new AparatCuratatGeamuri("abc", 34, 21, 33, 5, 3, 40, 4, 500, "asd", true, false, 34, 12);
                         vectAparatCuratatPardoseli = new AparatCuratatPardoseli[]{C, D, G};
                         vectAparatCuratatGeamuri = new AparatCuratatGeamuri[]{E, R, P};
                         vAparate=new Aparat[]{q,d,a,b,e,f,y,c,x,g,h,ascp1,ascp2,ascp3,s1,s2,s3,m1,m2,m3,mt1,mt2,mt3,
                        d1,d2,d3,t1,t2,t3,C,D,G,E,R,P};

	                 F=new File("History.txt"); 
                        
                         
                         
		}
          

	    public void afis(double p){boolean ok=false;
	      System.out.println("\n\n\t Aparat pret>400 : \n");
	      for(int i=0;i<vAparat.length;i++)
	          if(vAparat[i].getPret()>p) {System.out.println(vAparat[i]);ok=true;}
	       if(ok==false) System.out.println("\n\n\tNu exista\n");
	          
	  } 
	  
	  public void afis1(String tipDisplay){boolean ok=false;
	       System.out.println("\n\n\t Aspirator Uscat tipDisplay LED : \n");
	      for(int i=0;i<vAspiratorUscat.length;i++)
	          if(vAspiratorUscat[i].getTipDisplay().equals(tipDisplay)) {System.out.println(vAspiratorUscat[i]);ok=true;}
	       if(ok==false) System.out.println("\n\n\tNu exista\n");
	          
	  }
	  
	  public void afis1(boolean fir){boolean ok=false;
	         System.out.println("\n\n\t Aspirator Umed fir : \n");
	      for(int i=0;i<vAspiratorUmed.length;i++)
	          if(vAspiratorUmed[i].getFir()==fir) {System.out.println(vAspiratorUmed[i]);ok=true;}
	      if(ok==false) System.out.println("\n\n\tNu exista\n");
	      
	          
	  }
          
          public void afisASCP(double d){boolean ok=false;   
                 System.out.println("\n\n\t Aparat Spalare Cu Presiune>200 : \n");
              for(int i=0;i<vAparatSpalareCuPresiune.length;i++)  
                 if(vAparatSpalareCuPresiune[i].getDebit()>d) {System.out.println(vAparatSpalareCuPresiune[i]);ok=true;}  
              if(ok==false) System.out.println("\n\n\tNu exista\n");
          
           }
          
          public void afisS(double t){boolean ok=false;      
                System.out.println("\n\n\t Suflanta>10 : \n");
              for(int i=0;i<vSuflanta.length;i++)     //afisare vector
                  if(vSuflanta[i].getDebitAer()>t) {System.out.println(vSuflanta[i]);ok=true;}    
             if(ok==false) System.out.println("\n\n\tNu exista\n");
      
          
  }
          
          public void afis2(float b){
        boolean ok=false;
	
        System.out.println("\n\n\t Motosapa latimeLucruMax>50 : \n");
	for(int i=0;i<vMotosapa.length;i++){
	    if(vMotosapa[i].getLatimeLucruMax()==b) {
                System.out.println(vMotosapa[i]);
                ok=true;
            }
        }    
            if(ok==false) {
                System.out.println("\n\n\tNu exista\n");
            }  
	}
	  
          public void afis2(int n){
        boolean ok=false;
                System.out.println("\n\n\tMasinaTunsIarba nrViteze>4 : \n");
	for(int i=0;i<vMasinaTunsIarba.length;i++){
	    if(vMasinaTunsIarba[i].getNrViteze()>n) {
                System.out.println(vMasinaTunsIarba[i]);ok=true;
            }
        }   
            if(ok==false){
                System.out.println("\n\n\tNu exista\n");
            }
	}
          
           public void afisT(int n){boolean ok=false;
                System.out.println("\n\n\t Trimmer vitezaMaxima>200 : \n");
                for(int i=0;i<vTrimmer.length;i++)
                    if(vTrimmer[i].getVitezaMaxima()>n) {System.out.println(vTrimmer[i]);ok=true;}
                if(ok==false) System.out.println("\n\n\tNu exista\n");}

           public void afisD(int m){boolean ok = false;
                System.out.println("\n\n\t Drujba nr functii>3 : \n");
                for (int i = 0; i < vDrujba.length; i++)
                    if (vDrujba[i].getNrFunctii() > m) {
                    System.out.println(vDrujba[i]);
                    ok = true;
                }
                if (ok == false) System.out.println("\n\n\tNu exista\n");
        }
          
           public void afis3(int d) {
          int ok = 0;
                System.out.println("\n aparat curatat pardoseli diam>30:  \n");
               for (int i = 0; i < vectAparatCuratatPardoseli.length; i++)
                    if (vectAparatCuratatPardoseli[i].getDiametru() > d) {
                    System.out.println(vectAparatCuratatPardoseli[i]);
                ok = 1;

            }
               if (ok == 0) System.out.println("\n nu exista \n");

    }

        public void afis3(boolean c) {
        int ok = 0;
               System.out.println("\n Aparat curatat geamuri cablu \n");
              for (int i = 0; i < vectAparatCuratatGeamuri.length; i++)
                   if (vectAparatCuratatGeamuri[i].getCablu() == c) {
                   System.out.println(vectAparatCuratatGeamuri[i]);
                ok = 1;
            }
               if (ok == 0) System.out.println("\n nu exista \n");
    }
        
	    public String toString() {
	          return "\n\tClasa Aparat\n"+a+d+q+"\n\n\tClasa AspiratorUscat\n"+b+e+f+
	                  "\n\n\tClasa AspiratorUmed\n"+c+g+h+
	                  "\n\n\tVector Aparat\n"+vAparat[0]+vAparat[1]+vAparat[2]+"\n\n\tVector AspiratorUmed\n"
	                  +vAspiratorUmed[0]+vAspiratorUmed[1]+vAspiratorUmed[2]+"\n\n\tVector AspiratorUscat\n"+vAspiratorUscat[0]+
	                  vAspiratorUscat[1]+vAspiratorUscat[2]+
                          "\n\n\tClasa AparatSpalareCuPresiune\n"+ascp1+ascp2+ascp3+
                          "\n\n\tClasa Suflanta\n"+s1+s2+s3+
                          "\n\n\tVector AparatSpalareCuPresiune\n"
                           +vAparatSpalareCuPresiune[0]+vAparatSpalareCuPresiune[1]+vAparatSpalareCuPresiune[2]+"\n\n\tVector Suflanta\n"+vSuflanta[0]+
                           vSuflanta[1]+vSuflanta[2]+
                          "\n\n\tClasa MasinaTunsIarba\n"+mt1+mt2+mt3+
	                  "\n\n\tClasa Motosapa\n"+m1+m2+m3+
	                  "\n\n\tVector MasinaTunsIarba\n"
	                  +vMasinaTunsIarba[0]+vMasinaTunsIarba[1]+vMasinaTunsIarba[2]+"\n\n\tVector Motosapa\n"+vMotosapa[0]+
	                  vMotosapa[1]+vMotosapa[2]+
                          "\n\n\tClasa Drujba\n" + d1 + d2 + d3 + "\n\n\tClasa Trimmer\n" + t1 + t2 + t3 +
                          "\n\n\tVector Trimmer\n"
                           + vTrimmer[0] + vTrimmer[1] + vTrimmer[2] + "\n\n\tVector Drujba\n" + vDrujba[0] +
                          vDrujba[1] + vDrujba[2]+
                          "\n clasa aparat curatat pardoseli\n "+ C+D+G+
                          "\n clasa aparat curatat geamuri \n"+E+R+P+
                          "\nvector aparat curatat pardoseli \n"+
                          vectAparatCuratatPardoseli[0]+vectAparatCuratatPardoseli[1]+vectAparatCuratatPardoseli[2]+
                          "\n vector aparat curatat geamuri \n"+vectAparatCuratatGeamuri[0]+vectAparatCuratatGeamuri[1]+
                          vectAparatCuratatGeamuri[2];
                          
	    }
	  
//	    public static void main(String args[]) {
//	        TestClass t1=new TestClass();
//                
//	        System.out.println(t1);
//                
//                t1.afis(400);
//                
//	        t1.afis1("LED");
//	        t1.afis1(true);
//                
//                t1.afisASCP(380);
//	        t1.afisS(13);
//                
//                float latimeLucruMax = 50;
//	        t1.afis2(latimeLucruMax);
//                int nrViteze = 4;
//	        t1.afis2(nrViteze);
//                
//                t1.afisD(3);
//                t1.afisT(300);
//                
//                t1.afis3(30);
//                t1.afis3(true);
//                
//                
//	    }

}
