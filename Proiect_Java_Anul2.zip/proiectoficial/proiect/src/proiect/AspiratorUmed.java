package proiect;

import java.util.Arrays;
import java.util.Comparator;

public class AspiratorUmed extends Aparat{
                private int nrModuri, autonomie;
		private double capacitateRezervor;
		private boolean filtru, fir, timer;
		//constructor fara parametri(mostenire)
	public AspiratorUmed() {
		super();
		this.setDenumire("AspiratorUmed");
		this.nrModuri=1;
		this.autonomie=10;
		this.capacitateRezervor=2;
		this.filtru= true;
		this.fir= true;
		this.timer= true;
	}
		//constructor cu parametri(mostenire)
	public AspiratorUmed(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,
			int putere, int consum, double pret,int nrModuri, int autonomie, double capacitateRezervor, boolean filtru, boolean fir,
			boolean timer) {
		super(denumire,lungime, latime, inaltime,greutate, nrFunctii, putere,consum, pret);
		this.nrModuri = nrModuri;
		this.capacitateRezervor = capacitateRezervor;
		this.filtru = filtru;
		this.fir = fir;
		if(this.fir==true) this.autonomie = 0;
		else this.autonomie = autonomie;
		this.timer = timer;
	}
		//constructor de copiere(mostenire)
	public AspiratorUmed(AspiratorUmed A) {
		super(A);//modificare apel constructor de copiere
		this.nrModuri = A.nrModuri;
		this.autonomie = A.autonomie;
		this.capacitateRezervor =A.capacitateRezervor;
		this.filtru = A.filtru;
		this.fir = A.fir;
		this.timer = A.timer;
	}
	public int getNrModuri() {
		return nrModuri;
	}

	public void setNrModuri(int nrModuri) {
		this.nrModuri = nrModuri;
	}

	public int getAutonomie() {
		return autonomie;
	}

	public void setAutonomie(int autonomie) {
		this.autonomie = autonomie;
	}

	public double getCapacitateRezervor() {
		return capacitateRezervor;
	}

	public void setCapacitateRezervor(double capacitateRezervor) {
		this.capacitateRezervor = capacitateRezervor;
	}

	public boolean getFiltru() {
		return filtru;
	}

	public void setFiltru(boolean filtru) {
		this.filtru = filtru;
	}

	public boolean getFir() {
		return fir;
	}

	public void setFir(boolean fir) {
		this.fir = fir;
	}

	public boolean getTimer() {
		return timer;
	}

	public void setTimer(boolean timer) {
		this.timer = timer;
	}
	//metoda toString mostenire de la clasa Aparat(adaugare \t)
	public String toString() {
		return super.toString()+"\n\tnrModuri : "+nrModuri+"\n\tautonomie : "+autonomie+"\n\tcapacitateRezervor : "
				+capacitateRezervor+"\n\tfiltru : "+filtru+"\n\tfir : "+fir+"\n\ttimer: "+timer;
	}

        public class SortDen implements Comparator<AspiratorUmed>{
		public int compare(AspiratorUmed a,AspiratorUmed b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<AspiratorUmed>{
	 		public int compare(AspiratorUmed a,AspiratorUmed b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static AspiratorUmed[] sorT(AspiratorUmed[] a,int op) {
		AspiratorUmed[] b=new AspiratorUmed[a.length];
                b=a.clone();
		//System.arraycopy(a, 0, b, 0, b.length);
                if(op==1)
                {Arrays.sort(b, new AspiratorUmed().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new AspiratorUmed().new SortPret());
		                       return b; }
           return b;    
	}
       
}
