/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class AparatCuratatGeamuri extends Aparat{
   private String eficientaEnergetica;
   private boolean accesorii,cablu;
   private double autonomieAcumulator, capacitateColectare;

    public AparatCuratatGeamuri(){
        super();
        this.setDenumire("AparatCuratatGeamuri");
        this.cablu=false;
        this.eficientaEnergetica="a++";
        this.accesorii=true;
        this.autonomieAcumulator=5;
        this.capacitateColectare=10;
    }
    public AparatCuratatGeamuri(String denumire,float lungime,float latime,float inaltime,float greutate,int nrFunctii,int putere,int consum,double pret,
                                String eficientaEnergetica,boolean accesorii, boolean cablu, double autonomieAcumulator, double capacitateColectare){
        super(denumire,lungime,latime,inaltime,greutate,nrFunctii,putere,consum,pret);
        this.cablu=cablu;
        this.accesorii=accesorii;
        this.autonomieAcumulator=autonomieAcumulator;
        this.capacitateColectare=capacitateColectare;
        this.eficientaEnergetica=eficientaEnergetica;
    }

    public AparatCuratatGeamuri(AparatCuratatGeamuri A){
        super(A);
        this.accesorii=A.accesorii;
        this.autonomieAcumulator=A.autonomieAcumulator;
        this.cablu=A.cablu;
        this.capacitateColectare=A.capacitateColectare;
        this.eficientaEnergetica=A.eficientaEnergetica;
    }

    public final boolean getAccesorii(){
        return accesorii;
    }
    public void setAccesorii(boolean accesorii){
        this.accesorii=accesorii;
    }


    public final double  getAutonomieAcumulator(){
        return autonomieAcumulator;
    }
    public void setDenumire(double autonomieAcumulator){
        this.autonomieAcumulator=autonomieAcumulator;
    }

    public final boolean  getCablu(){
        return cablu;
    }
    public void setCablu(boolean cablu){
        this.cablu=cablu;
    }

    public final String getEficientaEnergetica(){
        return eficientaEnergetica;
    }
    public void setEficientaEnergetica(String eficientaEnergetica){
        this.eficientaEnergetica=eficientaEnergetica;
    }

    public final double getCapacitateColectare(){
        return capacitateColectare;
    }
    public void setCapacitateColectare(double capacitateColectare){
        this.capacitateColectare=capacitateColectare;
    }

    public String toString(){
        return super.toString()+"\n\tcablu : "+ cablu +"\n\teficentaEnergetica : " + eficientaEnergetica +"\n\taccesorii : " + accesorii + "\n\tautonomieAcumulator : " + 
                autonomieAcumulator + "\n\tcapacitateColectare : " + capacitateColectare;
    }

   public class SortDen implements Comparator<AparatCuratatGeamuri>{
        public int compare(AparatCuratatGeamuri a, AparatCuratatGeamuri b){
            return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
        }
    }

    public class SortPret implements Comparator<AparatCuratatGeamuri>{
        public int compare(AparatCuratatGeamuri a, AparatCuratatGeamuri b){
            return (int)(a.getPret()-b.getPret());
        }
    }
    public static AparatCuratatGeamuri [] sorT(AparatCuratatGeamuri[] a, int op){
       AparatCuratatGeamuri[] b=new AparatCuratatGeamuri[a.length];
        b=a.clone();
        if(op==1){
            Arrays.sort(b,new AparatCuratatGeamuri().new SortDen());
            return b;
        }
        if (op==2){
            Arrays.sort(b, new AparatCuratatGeamuri().new SortPret());
            return b;
        }
        return b;
    }
}
