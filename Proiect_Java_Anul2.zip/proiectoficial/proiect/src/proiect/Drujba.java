/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class Drujba extends Aparat{
      private String tipAlimentare, tipPornire, culoare;

    public Drujba(String denumire, float lungime, float latime, float inaltime, float greutate, int nrFunctii,
                  int putere, int consum, double pret, String tipAlimentare, String tipPornire, String culoare) {

        super(denumire, lungime, latime, inaltime, greutate, nrFunctii, putere, consum, pret);

        this.tipAlimentare = tipAlimentare;
        this.tipPornire = tipPornire;
        this.culoare = culoare;

    }

    public Drujba(Drujba A) {
        super(A);
        this.tipAlimentare = A.tipAlimentare;
        this.tipPornire = A.tipPornire;
        this.culoare = A.culoare;
    }

    public Drujba() {

        super();
        this.tipAlimentare ="";
        this.tipPornire ="";
        this.culoare = "";
    }


    public String getTipAlimentare() {

        return tipAlimentare;

    }

    public void setTipAlimentare(String noutipAlimentare) {

        this.tipAlimentare = noutipAlimentare;
    }

    public String getTipPornire() {

        return tipPornire;

    }

    public void setTipPornire(String noutipPornire) {

        this.tipPornire = noutipPornire;
    }

    public String getCuloare() {

        return culoare;

    }

    public void setCuloare(String nouaCuloare) {

        this.culoare = nouaCuloare;

    }

    public String toString() {
        return super.toString() + "\n\tculoare : " + culoare + "\n\ttipPornire :" + tipPornire + "\n\ttipAlimentare:" + tipAlimentare;

    }
    
    public class SortDen implements Comparator<Drujba>{
        public int compare(Drujba a,Drujba b) {
           return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());}}

     public class SortPret implements Comparator<Drujba>{
         public int compare(Drujba a,Drujba b) {
             return (int)(a.getPret()-b.getPret());}}

     public static Drujba[] sorT(Drujba[] a,int op) {
            Drujba[] b=new Drujba[a.length];
             b=a.clone();
               if(op==1)
                        {Arrays.sort(b, new Drujba().new SortDen());
                            return b; }
                        if(op==2)
                        {Arrays.sort(b, new Drujba().new SortPret());
                            return b; }
                        return b;
                    }

}
