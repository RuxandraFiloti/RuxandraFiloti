/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proiect;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author casap
 */
public class MasinaTunsIarba extends Aparat{
    private String tipAlimentare;
	private float latimeTaiere, inaltimeMedieTaiere, inaltimeMaxTaiere;
	private	int nrViteze;
	
	
	public MasinaTunsIarba (){
		super();
		this.tipAlimentare = " ";
		this.latimeTaiere = 0 ;
		this.inaltimeMaxTaiere = 0 ;
		this.inaltimeMedieTaiere = 0;
		this.nrViteze = 0 ;
		
	}

	
	public MasinaTunsIarba (String tipAlimentare, float latimeTaiere, 
		float inaltimeMedieTaiere, float inaltimeMaxTaiere, int nrViteze, String denumire,
	float lungime,float latime, float inaltime, int greutate,int nrFunctii,int putere, int consum, double pret){
		
		super(denumire, lungime,latime, inaltime,greutate,nrFunctii, putere,consum,pret);
		this.tipAlimentare = tipAlimentare;
		this.latimeTaiere = latimeTaiere;
		this.inaltimeMedieTaiere = inaltimeMedieTaiere;
		this.inaltimeMaxTaiere = inaltimeMaxTaiere;
		this.nrViteze = nrViteze;
		
	}
	
	
	public MasinaTunsIarba(MasinaTunsIarba M){
		super(M);
		this.tipAlimentare = M.tipAlimentare;
		this.latimeTaiere = M.latimeTaiere;
		this.inaltimeMaxTaiere = M.inaltimeMaxTaiere;
		this.inaltimeMedieTaiere = M.inaltimeMedieTaiere;
		this.nrViteze = M.nrViteze;
		
	}
	
	//getter

	public String getTipAlimetare (){
			return tipAlimentare;
			}
	//setter
	public void setTipAlimenare(String noutipAlimetare){
			this.tipAlimentare  = noutipAlimetare;
	}
	public float getLatimeTaiere (){
		return latimeTaiere;
	}
	public void setLatimeTaiere (float noulatimeTaiere){
		this.latimeTaiere = noulatimeTaiere;
	}
	public float getInaltimeMedieTaiere (){
		return inaltimeMedieTaiere;
	}
	public void setInaltimeMedieTaiere (float nouinaltimeMedieTaiere){
		this.inaltimeMedieTaiere = nouinaltimeMedieTaiere;
	}
	public float getInaltimeMaxTaiere (){
		return inaltimeMaxTaiere;
	}
	public void setInaltimeMaxTaiere ( float nouinaltimeMaxTaiere){
		this.inaltimeMaxTaiere = nouinaltimeMaxTaiere;
	}
	public int getNrViteze (){
		return nrViteze;
	}
	public void setNrViteze ( int nouNrViteze){
		this.nrViteze = nouNrViteze;
	}

	public String toString(){
	return super.toString() +"\n\tTip alimenate:" + tipAlimentare + "\n\tLatime taiere:" + 
	 	latimeTaiere + "\n\tInaltime medie taiere:" + inaltimeMedieTaiere + "\n\tInaltime max raiere:" + 
	 		inaltimeMaxTaiere +"\n\tNumar viteze:"+ nrViteze;
}
        
       public class SortDen implements Comparator<MasinaTunsIarba>{
		public int compare(MasinaTunsIarba a,MasinaTunsIarba b) {
			return a.getDenumire().toLowerCase().compareTo(b.getDenumire().toLowerCase());
		}
	}
	     
	public class SortPret implements Comparator<MasinaTunsIarba>{
	 		public int compare(MasinaTunsIarba a,MasinaTunsIarba b) {
	 			return (int)(a.getPret()-b.getPret());
	 		}
	 	}
	
	public static MasinaTunsIarba[] sorT(MasinaTunsIarba[] a,int op) {
		MasinaTunsIarba[] b=new MasinaTunsIarba[a.length];
                b=a.clone();
                if(op==1)
                {Arrays.sort(b, new MasinaTunsIarba().new SortDen());
                                   return b; }
                 if(op==2)
                {Arrays.sort(b, new MasinaTunsIarba().new SortPret());
		                       return b; }
           return b;    
	}

}
