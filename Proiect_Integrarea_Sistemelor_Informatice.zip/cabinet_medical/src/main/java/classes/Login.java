/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import static classes.Pacient.generateTable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author bella
 */
public class Login {
    
    public String login(String user,String pass)
    {
        try
        { String sqlGetLogin = "select count(*) nr from loginuser where username=? and password=?";
          int nr=0;
              PreparedStatement query = BDConnection.getPStatement(sqlGetLogin); //insert
            query.setString(1, user);
            query.setString(2, pass);
            ResultSet rs = query.executeQuery();
            while(rs.next()){
                nr=rs.getInt(1);
            }
          
            System.out.println("HERE: " + rs.next());
           return nr+"";
           // return "am inserat";
        }
        catch (SQLException ex)
        { return ex.getMessage();
          
        }
    
    }
    
}
