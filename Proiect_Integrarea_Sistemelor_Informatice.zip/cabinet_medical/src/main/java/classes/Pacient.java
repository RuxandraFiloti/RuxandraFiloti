/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bella
 */
public class Pacient {
    public String getPacienti()
    {
        try
        { String sqlGetPacienti = "SELECT * FROM pacient";
            ArrayList<String> pacienti = new ArrayList<String>();
            ResultSet rs = BDConnection.getStatement().executeQuery(sqlGetPacienti);
        
            ArrayList<String> headers = new ArrayList<String>();
            headers.add("cod_pacient");
            headers.add("CNP");
            headers.add("nume_pacient");
            headers.add("pren_pacient");
            headers.add("varsta_pacient");
            headers.add("adresa_pacient");
            System.out.println("HERE: " + rs.next());
           return generateTable(headers, rs);
           // return "am inserat";
        }
        catch (SQLException ex)
        { return ex.getMessage();
          
        }
    
    }
   
    public static String generateTable(ArrayList<String> headers, ResultSet rs)
    {
        try
        {
            StringBuffer a = new StringBuffer();
            ResultSet rs1 = rs;
            a.append("<table><tr>");
            for (String header : headers)
            {
                a.append("<th>" + header + "</th>");
            }
            ArrayList<String> columns = new ArrayList<String>();
            int noOfColumns;
            noOfColumns = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= noOfColumns; i++)
            {
                columns.add(rs.getMetaData().getColumnName(i).toString());
            }
            while (rs.next())
            {
                a.append("<tr>");
               
                for (int i = 0; i < columns.size(); i++)
                {
                    a.append("<td>" + rs.getString(i + 1) + "</td>");
                }
                a.append("</tr>");
            }
            a.append("</table>");
            return a.toString();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(Pacient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
     public void insertPacient(int cod_pacient, String CNP, String nume_pacient, String pren_pacient, int varsta_pacient, String adresa_pacient) {
       
        try {
            String sql = "insert into pacient values (?,?,?,?,?,?) ";
            PreparedStatement query = BDConnection.getPStatement(sql); //insert

//insert
            query.setInt(1, cod_pacient);
            query.setString(2, CNP);
            query.setString(3, nume_pacient);
            query.setString(4, pren_pacient);
            query.setInt(5, varsta_pacient);
            query.setString(6, adresa_pacient);

            query.executeUpdate(); //insert
           
//return "am terminat";
        } catch (SQLException e) {
          //  return e.getMessage();
        }
    }

    public String updatePacient(int cod_pacient, String CNP, String nume_pacient, String pren_pacient, int varsta_pacient, String adresa_pacient) {
       
        try {
             String sql = "update pacient set cnp=?,  nume_pacient=?, pren_pacient =?, varsta_pacient=?, adresa_pacient=? where cod_pacient=? ";
            PreparedStatement query = BDConnection.getPStatement(sql); //update

//update
            query.setString(1, CNP);
            query.setString(2, nume_pacient);
            query.setString(3, pren_pacient);
            query.setInt(4, varsta_pacient);
            query.setString(5, adresa_pacient);
            query.setInt(6, cod_pacient);
            query.executeUpdate(); //update
            return "am intrat in update";
          
        } catch (SQLException e) {
          return e.getMessage();
        }
    }

    public void deletePacient(int cod_pacient) {
       
        try {
        
            String sql = "delete from pacient where cod_pacient=?";
            PreparedStatement query = BDConnection.getPStatement(sql); //delete

//delete
            query.setInt(1, cod_pacient);

            query.executeUpdate(); //delete
           
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
