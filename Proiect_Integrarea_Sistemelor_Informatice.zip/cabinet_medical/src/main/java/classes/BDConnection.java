/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package classes;

 

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

 

/**
*
* @author casap
*/
public class BDConnection
{

 

    private static final String URL = "jdbc:mysql://localhost:3306/cabinet_medical";
    private static final String USER = "root";
    private static final String PASSWORD = "Ruxicristi1";
    private static Connection connection = null;

 

    public BDConnection()
    {
    }

 

    public static Connection getConnection()
            throws SQLException
    {
        if (connection == null)
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
            }
            catch (ClassNotFoundException e)
            {
                e.printStackTrace();
            }
        }
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
        return connection;
    }

 

    public static Statement getStatement()
            throws SQLException
    {
        Statement query = getConnection().createStatement();
        return query;
    }

 

    public static PreparedStatement getPStatement(String sql)
            throws SQLException
    {
        PreparedStatement query = getConnection().prepareStatement(sql);
        return query;
    }

 

    public static CallableStatement getCStatement(String sql)
            throws SQLException
    {
        CallableStatement query = getConnection().prepareCall(sql);
        return query;
    }

 

    public void errorHandling()
    {
        try
        {
            getConnection();
            getStatement();
            getPStatement("");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

 

    public static BDConnection getInstance()
    {
        return BDConnectionHolder.INSTANCE;
    }

 

    private static class BDConnectionHolder
    {

 

        private static final BDConnection INSTANCE = new BDConnection();
    }
}