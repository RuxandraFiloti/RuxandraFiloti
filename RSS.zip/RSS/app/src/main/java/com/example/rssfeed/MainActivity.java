package com.example.rssfeed;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import clase.InternetTools;
import clase.RssFeedModel;

public class MainActivity extends AppCompatActivity {
    private Button rssButton;
    private Button rssBrowser;
    private TextView rssTitle;
    private TextView rssUrl;

    private List<RssFeedModel> feedList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rssButton = (Button) findViewById(R.id.button);
        rssBrowser = (Button) findViewById(R.id.button3);
        rssTitle = (TextView) findViewById(R.id.rssTitle);
        rssUrl = (TextView) findViewById(R.id.rssUrl);

        //Primul buton declanșează solicitarea rețelei
        // și analizarea fluxului RSS de la o adresă URL codificată
        rssButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String urlRequestString = "www.bnr.ro/RSS_200043_BRL.aspx";
                URL urlRequestUrl = InternetTools.buildUrl(urlRequestString);
                rssUrl.setText(urlRequestUrl.toString());
                //rssUrl.setText("adresa web");
                new RequestTask().execute(urlRequestUrl);
                //RequestTask este o instanta a clasei RequestTask care cere http,
                // urlRequestUrl este parametrul pt cererea url
            }
        });

        //deschidere browser
        rssBrowser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //cod pt deschidere adresa in browser
                //Codul folosește clasa Uri pentru a analiza adresa șir într-un obiect URI
                String address = "https://www.bnr.ro/RSS-Feeds-4129-Mobile.aspx"; // Replace with your desired address
                 Uri uri = Uri.parse(address);
                // și apoi creează o intenție cu acțiunea ACTION_VIEW și obiectul URI ca date.
                 Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                // În cele din urmă, intenția este începută cu metoda startActivity
                 startActivity(intent);
            }
        });

    }
    //Fluxul RSS este analizat și stocat într-o Listă de obiecte RssFeedModel,
    // care sunt apoi convertite într-un șir și afișate în prima vizualizare de text.
    public String listToString(List<RssFeedModel> list){
        StringBuffer sirDeAfisat=new StringBuffer();
        for(RssFeedModel p:list) {
            sirDeAfisat.append("   "); //append=adauga
            sirDeAfisat.append(p);
            sirDeAfisat.append("\n");
        }
        return sirDeAfisat.toString();
    }
    //metoda parseFeed() analizează fluxul XML
    // și returnează o listă de obiecte RssFeedModel
    //Metoda ia ca argument un InputStream,
    // care este sursa datelor XML care trebuie analizate.
    public List<RssFeedModel> parseFeed(InputStream inputStream) throws XmlPullParserException, IOException {
        String title = null;
        String time = null;
        boolean isItem = false;
        List<RssFeedModel> items = new ArrayList<>();

        try {
            XmlPullParser xmlPullParser = Xml.newPullParser();
            //Acesta creează o nouă instanță a XmlPullParser și își setează caracteristica
            // să nu proceseze spațiile de nume.
            xmlPullParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            // Apoi setează fluxul de intrare pentru parser folosind metoda setInput()
            xmlPullParser.setInput(inputStream, null);

            //Apelează nextTag() pentru a avansa analizatorul la prima etichetă
            xmlPullParser.nextTag();
            //Acesta intră într-o buclă care continuă până la sfârșitul documentului XML
            while (xmlPullParser.next() != XmlPullParser.END_DOCUMENT) {
                //În interiorul buclei, primește tipul evenimentului curent
                // și numele etichetei folosind metodele getEventType() și, respectiv, getName()
                int eventType = xmlPullParser.getEventType();
                String name = xmlPullParser.getName();
                if(name == null)
                    continue;
                //Dacă tipul de eveniment curent este END_TAG și
                // numele etichetei este „item”, aceasta setează variabila isItem la false
                if(eventType == XmlPullParser.END_TAG) {
                    if(name.equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    continue;
                }
                //Dacă tipul de eveniment curent este START_TAG
                // și numele etichetei este „item”, aceasta setează variabila isItem la adevărat
                if (eventType == XmlPullParser.START_TAG) {
                    if(name.equalsIgnoreCase("item")) {
                        isItem = true;
                        continue;
                    }
                }

                //Log.d("Fisier parsat", "Parsing tag ==> " + name);
                String result = "";
                //Dacă tipul de eveniment curent este TEXT, acesta primește valoarea textului
                // folosind metoda getText()
                // și avansează analizatorul la următoarea etichetă folosind metoda nextTag().
                if (xmlPullParser.next() == XmlPullParser.TEXT) {
                    result = xmlPullParser.getText();
                    xmlPullParser.nextTag();
                }

                //Dacă numele etichetei este „title”,
                // aceasta setează variabila titlu la valoarea textului
                if (name.equalsIgnoreCase("title")) {
                    title = result;
                    //Log.d("de adaugat---", "title ==> " + title);
                    //Dacă numele etichetei este „pubDate”,
                    // setează variabila de timp la valoarea textului
                } else if (name.equalsIgnoreCase("pubDate")) {
                    time = result;
                    //Log.d("de adaugat---", "time ==> " + time);
                }
                //Dacă ambele variabile titlu și timp nu sunt nule și isItem este adevărat,
                if (title != null && time != null) {
                    if(isItem) {
                        // acesta creează un nou obiect RssFeedModel
                        // cu valorile titlului și timpului
                        RssFeedModel item = new RssFeedModel(title, time);
                        //și îl adaugă la lista de articole.
                        items.add(item);
                    }
                    //Apoi resetează variabilele title, time și isItem la null și, respectiv, false.
                    title = null;
                    time = null;
                    isItem = false;
                }
            }
            //log - utilizat pt monitorizare si depanare flux RSS
            //Prima linie înregistrează lista de articole ca șir folosind metoda toString().
            // Reprezentarea în șir a listei conține titlul fiecărui articol și ora,
            // separate prin virgule și cuprinse între paranteze drepte.
            Log.d("##items", " ==> " + items.toString());
            //A doua linie înregistrează numărul de elemente analizate din fluxul RSS
            // folosind metoda size(), care returnează numărul de elemente din listă
            Log.d("Total items","!! "+ items.size());
            return items;
        } finally {
            //în final, închide fluxul de intrare
            inputStream.close();
            //și returnează lista de items
            return items;
        }
    }
//Clasa RequestTask extinde AsyncTask și efectuează cererea de rețea
// și analiza pe un fir de execuție de fundal
// și returnează șirul rezultat la firul principal în metoda onPostExecute().
    private class RequestTask extends AsyncTask<URL, Void, String> {

        //executa o cerere de retea folosind url ul dat preluand raspunsul la flux de intrare
        // aceasta intrare este apoi analizata folosind un analizator xml
        // si rezultate sunt returnate sub forma de sir de caractere
        protected String doInBackground(URL... params) {
            URL searchUrl = params[0];
            String urlResults = null;
            feedList=null;
            try {
                InputStream inputStream = InternetTools.getResponse(searchUrl);
                feedList = parseFeed(inputStream);
                return listToString(feedList);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            }
            return listToString(feedList);
        }

        //afiseaza acest sir intr-un obiect RSS title daca este disponibil
        protected void onPostExecute(String getResults) {
            System.out.println("==="+getResults);
            if (getResults != null && !getResults.equals("")) {
                rssTitle.setText(getResults);
            }
        }
    }
}