package clase;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

//clasa furnizeaza metode pt crearea unui url si preia raspunsuri http

public class InternetTools {
    final static String UrlBaza = "https://";

    //construieste un URL
    //metoda statica care are un string (numeComponenta) si returneaza un url

    public static URL buildUrl(String numeComponenta) {
        URL urlFinal = null;
        //creeaza url-ul final prin append-ul obiectului numeComponenta si urlBaza
        try {
            urlFinal = new URL(UrlBaza+numeComponenta);
            //daca exista o exceptie la formarea url-ului, se afiseaza o eroare
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return urlFinal;
    }

    //primeste un raspuns HTTP pentru URL argument
    //ia obiectul urlFinal si returneaza un InputStream (flux de intrare)
    public static InputStream getResponse(URL urlFinal) throws IOException {
        //se deschide conexiunea http, folosind urlFinal si preia input stream din conexiune
        HttpURLConnection connection = (HttpURLConnection) urlFinal.openConnection();
        InputStream in=null;
        //exceptie la preluarea input stream
        try {
            in = connection.getInputStream();
            return in;
        } finally {
            connection.disconnect();
        }
    }
}
