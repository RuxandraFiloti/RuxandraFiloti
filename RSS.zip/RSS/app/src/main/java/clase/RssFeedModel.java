package clase;

//clasa care prezinta un rss feed
public class RssFeedModel {
    public String title;
    public String time;


    //constructor cu parametrii
    public RssFeedModel(String title, String time) {
        this.title = title;
        this.time=time;

    }
    //afisare
    public String toString(){
        return "--"+title+"\n----"+time+"\n";
    }
}
