package clase;

public class Pacient {
    private String nume;
    private int varsta;
    private double inaltime;
    private boolean fumator;
    private char gen;

    //constructor cu parametri
    public Pacient(String nume, int varsta, double inaltime, boolean fumator, char gen) {
        this.nume = nume; //this -> referinta la obiectul curent din constructor;
        this.varsta = varsta; //this elimina confuzia dintre atributele clasei si parametrii
        this.inaltime = inaltime;
        this.fumator = fumator;
        this.gen = gen;
    }
    //constructor primește doar primele trei proprietăți și setează
    // valorile implicite pentru proprietățile restante (fumator=false, gen='N')
    public Pacient(String nume, int varsta, double inaltime) {
        this(nume, varsta, inaltime, false, 'N');
    }

    //constructor primește doar primele trei proprietăți și
    // setează valorile implicite pentru proprietățile inaltime (0) și gen ('N'),
    // dar permite specificarea valorii proprietății fumator
    public Pacient(String nume, int varsta, boolean fumator) {
        this(nume, varsta, 0, fumator, 'N');
    }

    //metode get pentru fiecare proprietate, astfel încât valorile lor
    // să poată fi accesate din afara clasei, dar nu pot fi modificate direct
    public String getNume() {
        return nume;
    }

    public int getVarsta() {
        return varsta;
    }

    public double getInaltime() {
        return inaltime;
    }

    public boolean isFumator() {
        return fumator;
    }

    public char getGen() {
        return gen;
    }

    @Override
    public String toString() {
        return "Pacient{" +
                "nume='" + nume + '\'' +
                ", varsta=" + varsta +
                ", inaltime=" + inaltime +
                ", fumator=" + fumator +
                ", gen=" + gen +
                '}';
    }
}