package clase;

import java.util.ArrayList;

//Clasa GrupPacienti conține două proprietăți private:
// pacienti de tip ArrayList de Pacient, care va stoca o listă de obiecte Pacient,
// și numeGrup de tip String, care va stoca numele grupului de pacienți.
// Constructorul primește un ArrayList de Pacient și un String
// reprezentând numele grupului și setează valorile celor două proprietăți.
public class GrupPacienti {
    private ArrayList<Pacient> pacienti;
    private String numeGrup;

    //constructor cu parametrii
    public GrupPacienti(ArrayList<Pacient> pacienti, String numeGrup) {

        this.pacienti = new ArrayList<>(pacienti); //initializeaza o lista noua ca sa nu mai depinda de referinte
        this.numeGrup = numeGrup;
    }

    //metode get pentru fiecare proprietate, astfel încât valorile lor
    // să poată fi accesate din afara clasei, dar nu pot fi modificate direct
    public ArrayList<Pacient> getPacienti() { //oferă acces la lista de pacienți

        return pacienti;
    }

    public String getNumeGrup() { //oferă acces la numele grupului

        return numeGrup;
    }
}
