package clase;

import java.util.ArrayList;

// clasă cu numele VizualizareGrupPacienti care are o proprietate
// grupPacienti de tipul GrupPacienti. În constructorul clasei,
// am creat o listă de pacienți listaPacienti
// și am adăugat 6 obiecte de tip Pacient în această listă.
// Apoi, am creat o instanță a clasei GrupPacienti,
// cu lista de pacienți specificată
// și cu un nume de grup "Grup de pacienți",
// și am stocat această instanță în proprietatea grupPacienti.
// Aceasta va crea o instanță de tip GrupPacienti
// cu numele "Grup de pacienți" și lista de pacienți specificată.


public class VizualizareGrupPacienti {
    public GrupPacienti grupPacienti;

    public VizualizareGrupPacienti() {
        ArrayList<Pacient> listaPacienti = new ArrayList<>();
        listaPacienti.add(new Pacient("Ion", 35, 1.75, true, 'M'));
        listaPacienti.add(new Pacient("Maria", 28, 1.6, false, 'F'));
        listaPacienti.add(new Pacient("Alex", 45, 1.85, true, 'M'));
        listaPacienti.add(new Pacient("Ana", 20, 1.65, false, 'F'));
        listaPacienti.add(new Pacient("Dan", 60, 1.78, true, 'M'));
        listaPacienti.add(new Pacient("Laura", 42, 1.63, true, 'F'));
        listaPacienti.add(new Pacient("Mihai", 30, 1.87, false, 'M'));
        listaPacienti.add(new Pacient("Georgiana", 19, 1.7, false, 'F'));
        listaPacienti.add(new Pacient("Daniel", 25, 1.81, true, 'M'));
        listaPacienti.add(new Pacient("Elena", 41, 1.74, false, 'F'));

        this.grupPacienti = new GrupPacienti(listaPacienti, "Grup de pacienți");
    }
}

