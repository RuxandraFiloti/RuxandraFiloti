package com.example.proiect_eim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import clase.VizualizareGrupPacienti;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //conversie de tip cast (conversie de la un tip de data la altul)-> (TextView)
        TextView afis = (TextView) findViewById(R.id.textView); //legatura dintre java si interfata
        TextView varsta = (TextView) findViewById(R.id.textView4);
        Button afisare = (Button) findViewById(R.id.button);
        Button filtrare = (Button) findViewById(R.id.button2);
        CheckBox fumator = (CheckBox) findViewById(R.id.checkBox);
        SeekBar varsta1 = (SeekBar) findViewById(R.id.seekBar);
        Button activitate = (Button) findViewById(R.id.button3);
        //se creeaza o noua instanta a clasei VizualizareGrupPacienti
        //si o atribuie variabilei vgp
        //folosita pt afisarea listei de pacienti
        VizualizareGrupPacienti vgp = new VizualizareGrupPacienti();



        afisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //obiect StringBuffer numit sb, care va fi utilizat pentru a
                // construi un șir de caractere
                // care va fi afișat într-un TextView
                StringBuffer sb = new StringBuffer();
                //Apelul metodei forEach este utilizat pentru a itera prin lista de pacienți
                // din GrupPacienti și pentru a adăuga reprezentarea
                // sub formă de șir de caractere a fiecărui pacient în obiectul StringBuffer
                vgp.grupPacienti.getPacienti().forEach(pacient ->
                {            sb.append(pacient.toString()); //sageata parcurgere recursiv lista
                    sb.append("\n");    }); //se adauga in sb lista de pacienti
                //șirul de caractere construit este setat ca text în elementul de interfață grafică,
                // prin intermediul metodei setText a unui obiect de tip TextView numit afis
                afis.setText(sb.toString());
            }
        });

        filtrare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //obiect StringBuffer numit sb, care va fi utilizat pentru a
                // construi un șir de caractere
                // care va fi afișat într-un TextView
                StringBuffer sb = new StringBuffer();

                //forEach este utilizată pentru a itera prin lista de pacienți din GrupPacienti
                // și pentru a verifica dacă fiecare pacient îndeplinește anumite criterii de filtrare
                vgp.grupPacienti.getPacienti().forEach(pacient ->
                {
                    boolean este_fumator = fumator.isChecked();

                    //Dacă fumator este bifat, atunci pacientul trebuie să fie fumător
                    // și să aibă o vârstă mai mare decât valoarea selectată pe varsta1
                    if (este_fumator) {
                        if (pacient.isFumator()&&pacient.getVarsta() > varsta1.getProgress()) {
                            sb.append(pacient.toString());
                            sb.append("\n");
                        }
                    } else {
                        //Dacă fumator nu este bifat, atunci pacientul trebuie să nu fie fumător
                        // și să aibă o vârstă mai mare decât valoarea selectată pe varsta1
                        if (!pacient.isFumator()&&pacient.getVarsta() > varsta1.getProgress()) {
                            sb.append(pacient.toString());
                            sb.append("\n");
                        }
                    }
                });
                afis.setText(sb.toString());
            }
        });

        //listener pe butonul pt cea de a doua fereastra
        activitate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //intentie de a lansa a doua fereastra din prima fereastra
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                //metoda putExtra ataseaza date suplimentare la intent
                intent.putExtra("varsta", varsta1.getProgress());
                //"varsta" este o cheie si face legatura intre varsta aleasa pe seekbar
                //si afisarea ei pe pagina a doua
                intent.putExtra("esteFumator", fumator.isChecked());
                //"esteFumator" este cheie si face legatura intre checkboxul bifat sau nu
                //si afisarea lui in functie de starea aleasa
                startActivity(intent); //lanseaza a doua fereastra
            }
        });
        varsta1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            //Ascultătorul implementează trei metode: onProgressChanged, onStartTrackingTouch și onStopTrackingTouch
            @Override
            //Atunci când utilizatorul modifică poziția cursorului de pe bara de căutare.
            // Argumentele metodei includ obiectul SeekBar în sine,
            // noua poziție a cursorului și un boolean care indică dacă evenimentul a fost declanșat de utilizator.
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                varsta.setText("Varsta: " + i);
            }

            //Metodele onStartTrackingTouch și onStopTrackingTouch sunt apelate atunci când utilizatorul începe sau termină interacțiunea cu bara de căutare. În cazul de față, aceste metode nu fac nimic, deoarece
            // nu este necesară nicio acțiune suplimentară atunci când utilizatorul începe sau termină interacțiunea cu bara de căutare
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}