package com.example.proiect_eim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView activitate = (TextView) findViewById(R.id.textView2);
        Button inapoi = (Button) findViewById(R.id.button4);
        //Metoda getIntent() este folosită
        // pentru a prelua intentul care a început activitatea curentă.
        Intent intent = getIntent();
        //Metoda getIntExtra() este apoi folosită pentru a extrage valoarea întreagă
        // asociată cu cheia „varsta”.
        // Dacă cheia nu este găsită în intent, metoda va returna valoarea implicită -1
        activitate.setText("varsta: " + intent.getIntExtra("varsta", -1) + "\nfumator: " + intent.getBooleanExtra("esteFumator", false));
        //metoda getBooleanExtra() este utilizată pentru a extrage valoarea booleană asociată cu cheia „esteFumator”.
        // Dacă cheia nu este găsită în intentie, metoda va returna valoarea implicită false.

        //listener pt butonul care merge la prima fereastra
        inapoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //cand se apasa butonul se intoarce la prima fereastra
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent); //se lanseaza prima fereastra
            }
        });

    }
}