﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Client
{
    public class Maze : Panel
    {
        public int[,] maze;
        //        = new int[,] {
        //   {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        //    {0, 1, 0, 1, 1, 0, 1, 1, 1, 0},
        //    {0, 1, 1, 1, 1, 1, 1, 0, 1, 0},
        //    {0, 1, 1, 0, 1, 1, 0, 0, 1, 0},
        //    {0, 1, 1, 0, 0, 0, 1, 1, 1, 0},
        //    {0, 1, 0, 1, 1, 1, 1, 0, 0, 0},
        //    {0, 0, 0, 1, 0, 0, 1, 1, 1, 0},
        //    {0, 1, 0, 1, 1, 0, 1, 0, 1, 0},
        //    {0, 1, 1, 0, 0, 1, 1, 1, 1, 0},
        //    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        //};
        private readonly int squareSize;

        public readonly List<Point> track = new List<Point>();
        public List<TreasureHints> treasureTrack = new List<TreasureHints>();
        public List<Point> plusPoints = new List<Point>();
        public List<Point> minusPoints = new List<Point>();
        public Point treasure;
        public Maze(int[,] maze)
        {
            Location = new Point(0, 0);

            DoubleBuffered = true;
            Size = new Size(550, 550);
            Paint += new PaintEventHandler(Maze_Paint);
            BackColor = Color.White;
            Click += new EventHandler(Maze_Click);
            //  Enter += Maze_Enter;
            MouseEnter += new EventHandler(Maze_Enter);
            //  KeyDown += Maze_KeyDown;
            squareSize = 50;
            this.maze = maze;
            createTrack(maze);

        }

        private void Maze_KeyDown(object sender, KeyEventArgs e)
        {
            Console.WriteLine("Key");
        }

        private void Maze_Enter(object sender, EventArgs e)
        {
            // Focus();
            // Console.WriteLine("Enter");
        }

        public void createTrack(int[,] maze)
        {
            for (int i = 0; i < maze.GetLength(0); i++)
            {
                for (int j = 0; j < maze.GetLength(1); j++)
                {
                    int x = j * 50;
                    int y = i * 50;

                    switch (maze[i, j])
                    {
                        case 0:
                            //   track.Add(new Point(x + 50, y + 100));
                            //      Console.WriteLine("Point added: " + x + " " + y); 

                            break;
                        case 3:
                            track.Add(new Point(x, y));
                            plusPoints.Add(new Point(x, y));
                            break;
                        case 5:
                            track.Add(new Point(x, y));
                            minusPoints.Add(new Point(x, y));
                            break;
                        case 7:
                            track.Add(new Point(x, y));
                            treasureTrack.Add(new TreasureHints(new Point(x, y), "Treasure is "));
                            break;
                        case 9:
                            track.Add(new Point(x, y));
                            treasure = new Point(x, y);
                            break;
                        default: track.Add(new Point(x, y)); break;

                    }

                }
            }

            treasureTrack = GetTreasureHints(treasure, treasureTrack);


        }

        private void DrawMaze(Graphics g)
        {

            Color c = Color.BlanchedAlmond;
            for (int i = 0; i < maze.GetLength(0); i++)
            {
                for (int j = 0; j < maze.GetLength(1); j++)
                {
                    int x = j * squareSize;
                    int y = i * squareSize;

                    switch (maze[i, j])
                    {
                        case 1:
                            // track.Add(new Point(x + 50, y + 100));
                            c = Color.White;
                            //      Console.WriteLine("Point added: " + x + " " + y); 
                            break;
                        case 3: c = Color.Yellow; break;
                        case 5: c = Color.MediumVioletRed; break;
                        case 7: c = Color.AliceBlue; break;
                        case 9: c = Color.White; break;
                        default: c = Color.BlanchedAlmond; break;
                    }

                    Rectangle rect = new Rectangle(x, y, squareSize, squareSize);

                    using (Brush brush = new SolidBrush(c))
                    using (Pen pen = new Pen(Color.Black, 2))
                    {
                        g.FillRectangle(brush, rect);
                        g.DrawRectangle(pen, rect);
                    }


                }
            }
        }
        private void Maze_Paint(object sender, PaintEventArgs e)
        {
            DrawMaze(e.Graphics);
        }

        private void Maze_Click(object sender, EventArgs e)
        {
            //  Console.WriteLine("Click");
            // Focus();
        }

        public static bool checkPointInTrack(Point x, List<Point> track)
        {
            // Console.WriteLine("TRack: " + x.ToString() + " " + track.Count);
            foreach (Point i in track)
            {
                //  Console.WriteLine(i.ToString());
                if (i.Equals(x))
                {
                    return true;
                }
            }
            return false;
        }

        public static string checkPointInTreasureTrack(Point x, List<TreasureHints> track)
        {
            // Console.WriteLine("TRack: " + x.ToString() + " " + track.Count);
            foreach (TreasureHints i in track)
            {
                //  Console.WriteLine(i.ToString());
                if (i.point.Equals(x))
                {
                    return i.message;
                }
            }
            return null;
        }

        public static List<TreasureHints> GetTreasureHints(Point treasure, List<TreasureHints> track)
        {
            List<TreasureHints> a = new List<TreasureHints>();
            foreach (TreasureHints hint in track)
            {
                if (hint.point.X < treasure.X)
                {
                    a.Add(new TreasureHints(hint.point, hint.message += "East"));
                    continue;
                }
                else if (hint.point.X > treasure.X)
                {
                    a.Add(new TreasureHints(hint.point, hint.message += "West"));
                    continue;
                    //  message += "West";
                }

                if (hint.point.Y < treasure.Y)
                {
                    a.Add(new TreasureHints(hint.point, hint.message += "South"));
                    continue;
                }
                else if (hint.point.Y > treasure.Y)
                {
                    a.Add(new TreasureHints(hint.point, hint.message += "North"));
                    continue;
                }

                // assign message to hint object
            }
            return a;
        }


    }

    public class TreasureHints
    {
        public Point point { get; set; }
        public string message { get; set; }

        public TreasureHints(Point point, string message)
        {
            this.point = point;
            this.message = message;
        }
    }
}
