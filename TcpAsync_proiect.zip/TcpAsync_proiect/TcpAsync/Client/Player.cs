﻿using Connection;
using Server;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Client
{

    public class Player : Panel
    {
        public readonly int radius = 25;
        public Point location;
        public readonly Brush fillBrush;
        public Maze panel;
        public bool InFocus = false;
        public string userName;
        public Color C;
        public readonly TCPConnection connection;
        public static bool canStart = false;
        public int score = 0;
        public Player(TCPConnection con, Maze panel, Point pos, Color c, string name = null)
        {
            Parent = panel;
            Size = new Size(radius * 2, radius * 2);
            Paint += new PaintEventHandler(DrawCircle);
            Click += Player_Click;
            Console.WriteLine("here");
            //   KeyDown += MoveCircle;
            KeyPress += MoveCirclePressed;
            //  KeyUp += MoveCircle;
            LostFocus += PlayerLostFocus;
            //MouseMove += PlayerLostFocus;
            DoubleBuffered = true;

            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            this.panel = panel;
            Random random = new Random();
            // int index = random.Next(Maze.track.Count - 1);
            //  Point p = Maze.track[index];
            Console.WriteLine("LOCATION: " + panel.Location.ToString());
            Console.WriteLine("Pos: " + pos.ToString());
            Location = pos;
            location = Location;
            C = c;
            fillBrush = new SolidBrush(c);
            //    panel.Focus();
            //     Focus();
            userName = name;

            connection = con;
            panel.Controls.Add(this);

        }

        public Player(Player copyPlayer)
        {
            Parent = copyPlayer.panel;
            Size = new Size(radius * 2, radius * 2);
            Paint += new PaintEventHandler(DrawCircle);
            Click += Player_Click;
            Console.WriteLine("here");
            //   KeyDown += MoveCircle;
            KeyPress += MoveCirclePressed;
            //  KeyUp += MoveCircle;
            LostFocus += PlayerLostFocus;
            //MouseMove += PlayerLostFocus;
            DoubleBuffered = true;

            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            panel = copyPlayer.panel;
            Random random = new Random();
            // int index = random.Next(Maze.track.Count - 1);
            //  Point p = Maze.track[index];
            Console.WriteLine("LOCATION: " + copyPlayer.panel.Location.ToString());
            Console.WriteLine("Pos: " + copyPlayer.Location.ToString());
            Location = copyPlayer.Location;
            location = copyPlayer.Location;
            C = copyPlayer.C;
            fillBrush = new SolidBrush(copyPlayer.C);
            //    panel.Focus();
            //     Focus();
            userName = copyPlayer.userName;

            connection = copyPlayer.connection;
            panel.Controls.Add(this);
        }

        private void PlayerLostFocus(object sender, EventArgs e)
        {
            //     Console.WriteLine("Not in focus" + InFocus);
            if (InFocus)
            {
                //   Console.WriteLine("Back in focus" + InFocus);
                Focus();
                InFocus = true;
            }
        }

        private void Player_Click(object sender, EventArgs e)
        {
            Focus();
            InFocus = true;
            //Console.WriteLine("Click");
        }

        private void DrawCircle(object sender, PaintEventArgs e)
        {
            e.Graphics.FillEllipse(fillBrush, 0, 0, radius * 2, radius * 2);
        }

        private void MoveCircle(object sender, KeyEventArgs e)
        {
            InFocus = true;
            Focus();
            //  Console.WriteLine("KEY DOWN: " + e.KeyCode.ToString());
            int stepSize = 50;
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (location.Y - stepSize >= 0)
                    {
                        location.Y -= stepSize;
                    }
                    break;
                case Keys.Down:
                    if (location.Y + stepSize <= Parent.Height - radius * 2)
                    {
                        location.Y += stepSize;
                    }
                    break;
                case Keys.Left:
                    if (location.X - stepSize >= 0)
                    {
                        location.X -= stepSize;
                    }
                    break;
                case Keys.Right:
                    if (location.X + stepSize <= Parent.Width - radius * 2)
                    {
                        location.X += stepSize;
                    }
                    break;
                default:
                    break;
            }
            Location = location;
        }

        public void MoveCirclePressed(object sender, KeyPressEventArgs e)
        {
            if (canStart == false)
            {
                return;
            }

            InFocus = true;
            Focus();
            //   Console.WriteLine("KEY Press: " + e.KeyChar.ToString());
            int stepsize = 50;
            switch (e.KeyChar)
            {
                case 'w':
                    if (Maze.checkPointInTrack(new Point(location.X, location.Y - stepsize), panel.track))
                    {
                        location.Y -= stepsize;
                        UpdatePosition(location);
                        string message = Maze.checkPointInTreasureTrack(location, panel.treasureTrack);
                        if (message != null)
                        {
                            ChatBox.UpdateLabel(message);
                        }
                    }
                    break;
                case 's':
                    if (Maze.checkPointInTrack(new Point(location.X, location.Y + stepsize), panel.track))
                    {
                        location.Y += stepsize;
                        UpdatePosition(location);
                        string message = Maze.checkPointInTreasureTrack(location, panel.treasureTrack);
                        if (message != null)
                        {
                            ChatBox.UpdateLabel(message);
                        }
                    }
                    break;
                case 'a':
                    if (Maze.checkPointInTrack(new Point(location.X - stepsize, location.Y), panel.track))
                    {
                        location.X -= stepsize;
                        UpdatePosition(location);
                        string message = Maze.checkPointInTreasureTrack(location, panel.treasureTrack);
                        if (message != null)
                        {
                            ChatBox.UpdateLabel(message);
                        }
                    }
                    break;
                case 'd':
                    if (Maze.checkPointInTrack(new Point(location.X + stepsize, location.Y), panel.track))
                    {
                        location.X += stepsize;
                        UpdatePosition(location);
                        string message = Maze.checkPointInTreasureTrack(location, panel.treasureTrack);
                        if (message != null)
                        {
                            ChatBox.UpdateLabel(message);
                        }
                    }
                    break;
                default:
                    break;
            }
            Location = location;
            if (location.Equals(panel.treasure))
            {
                score += 200;
                BeginInvoke(new Action(() => { UpdateScore(score); panel.Invalidate(); }));
                connection.send(Commands.CreateMessage(Commands.TreasureFound, Commands.None, null));
                // ChatBox.UpdateLabel("Treasure found!!!");
            }
            if (Maze.checkPointInTrack(location, panel.plusPoints))
            {
                score += 100;
                UpdateScore(score);
            }

            if (Maze.checkPointInTrack(location, panel.minusPoints)) { score -= 50; UpdateScore(score); }

        }

        public void UpdatePosition(Point location)
        {
            byte[] data = Commands.CreateMessage(Commands.UserMoved, Commands.None, null, userName, null,
                   location.X.ToString(), location.Y.ToString());

            connection.send(data);
        }

        public void UpdateScore(int value)
        {

            byte[] data = Commands.CreateMessage(Commands.ScoreChanged, Commands.None, value.ToString(), userName);

            connection.send(data);
            ChatBox.UpdateScore(value);
        }
    }



}
