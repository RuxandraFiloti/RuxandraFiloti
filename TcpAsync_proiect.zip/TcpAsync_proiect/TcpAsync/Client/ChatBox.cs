﻿using Connection;
using Newtonsoft.Json;
using Server;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Label = System.Windows.Forms.Label;

namespace Client
{
    public partial class ChatBox : Form
    {
        private readonly TCPConnection con;
        public static Label treasureHints;
        public static Label score;
        private Player circle;
        private static readonly List<Player> players = new List<Player>();

        private Maze maze;
        public bool mazeReceived = false;
        public int[,] mazeMatrix;
        private readonly Random random = new Random();
        private readonly string me;
        private static string meStatic;
        private static TCPConnection tcpCon;
        private readonly string room;
        public ChatBox(TCPConnection con, string me, string room)
        {
            InitializeComponent();
            this.con = con;
            con.OnReceiveCompleted += con_OnReceiveCompleted;
            con.OnExceptionRaised += con_OnExceptionRaised;
            //      con.send(Commands.CreateMessage(Commands.GetMaze, Commands.None, null), room);
            userlist.Items.Add("All users");
            userlist.SelectedIndex = 0;
            //  Load += ChatBox_Load;

            //circle = new Player(maze);
            //{
            //    //  Location = new Point(maze.Location.X, maze.Location.Y)

            //};

            //maze.MouseHover += ChatBox_MouseHover;
            //maze.MouseMove += ChatBox_MouseHover;
            //maze.MouseEnter += ChatBox_MouseHover;
            //maze.MouseLeave += ChatBox_MouseLeave;
            ////   Controls.Add(circle);
            //Controls.Add(maze);
            // circle.BringToFront();
            //  circle.Focus();
            KeyPreview = true;
            this.me = me;
            this.room = room;
            treasureHints = new Label
            {
                Location = new Point(429, 619),
                Text = "Find the treasure!"
            };
            Controls.Add(treasureHints);
            score = new Label
            {
                Location = new Point(222, 613),
                Text = "Score: 0"
            };
            Controls.Add(score);
            SetMe();
        }
        public void SetMe()
        {
            meStatic = me;
            tcpCon = con;
        }
        private void ChatBox_MouseLeave(object sender, EventArgs e)
        {

            // Console.WriteLine("Back to focus: " + circle.InFocus);
        }

        private void ChatBox_MouseHover(object sender, EventArgs e)
        {
            //if (players.Count == 1)
            //{
            //    players[0].InFocus = true;
            //    players[0].Focus();
            //}
            handleFocus(true);

            //    Console.WriteLine("Back to focus: " + circle.InFocus);
        }

        private void con_OnExceptionRaised(object sender, ExceptionRaiseEventArgs args)
        {
            Application.Exit();
        }

        public ChatBox()
        {
            InitializeComponent();
            userlist.Items.Add("All users");
            userlist.SelectedIndex = 0;
        }

        private void ChatBox_Load(object sender, EventArgs e)
        {
            con.send(Commands.CreateMessage(Commands.GetMaze, Commands.None, null), room);
            con.send(Commands.CreateMessage(Commands.UserList, Commands.Request, null));
        }

        private delegate void ReceiveFunctionCall(string text);
        private string incompleteMessage = null;


        private void ReceieveMessage(string text)
        {

            if (incompleteMessage != null)
            {
                text = incompleteMessage + text;
            }
            if (text.Contains(Commands.UserMoved) || text.Contains(Commands.GetMaze) || text.Contains(Commands.ScoreChanged))
            {
                ;
            }
            else
            {

                chatField.Text += text + "\r\n";
            }

            chatField.SelectionStart = chatField.TextLength;
            chatField.ScrollToCaret();

            string[] messages = text.Split(new string[] { Commands.EndMessageDelim }, StringSplitOptions.RemoveEmptyEntries);

            if (messages.Length > 0)
            {
                //verifies if last message is complete (correction = 0)
                //if not (correction = 1) it will be stored for further use
                int correction = (text.EndsWith(Commands.EndMessageDelim) ? 0 : 1);
                if (correction == 1)
                {
                    incompleteMessage = messages[messages.Length - 1];
                }
                else
                {
                    incompleteMessage = null;
                }

                for (int i = 0; i < messages.Length - correction; i++)
                {
                    Commands.Message message = Commands.DecodeMessage(messages[i]);

                    switch (message.Command)
                    {
                        case Commands.UserList:
                            switch (message.Subcommand)
                            {
                                case Commands.Add:
                                    //if (userlist.Items.Contains(message.User))
                                    //{
                                    //    break;
                                    //}

                                    userlist.Items.Add(message.User);
                                    if (message.Data != null && message.Data.Contains("True"))
                                    {
                                        if (message.User == me)
                                        {
                                            start.Hide();
                                            score.Hide();
                                            treasureHints.Hide();
                                        }
                                        break;
                                    }

                                    Console.WriteLine("HERE " + maze + " " + message.XPosition + " " + message.YPosition);
                                    Player p = new Player(con, maze,
                                        new Point(int.Parse(message.XPosition), int.Parse(message.YPosition)),
                                        Color.FromArgb(int.Parse(message.Red),
                                        int.Parse(message.Green),
                                        int.Parse(message.Blue)), message.User.ToString());
                                    players.Add(p);
                                    Console.WriteLine("Player added: " + p.userName + " " + me);
                                    if (p.userName == me)
                                    {
                                        circle = p;
                                        Controls.Add(circle);

                                        circle.BringToFront();
                                        circle.Focus();
                                    }
                                    if (players.Count > 1)
                                    {
                                        start.Enabled = true;
                                    }

                                    break;
                                case Commands.Remove:
                                    //if (players.Count == 0)
                                    //{
                                    //    Close();
                                    //    break;
                                    //}

                                    userlist.Items.Remove(message.Data);
                                    Player playerToRemove = players.Find(player => player.userName == message.Data);
                                    if (playerToRemove == null)
                                    {
                                        break;
                                    }

                                    if (players.Count > 1)
                                    {
                                        players.Remove(playerToRemove);
                                        maze.Controls.Remove(playerToRemove);
                                        maze.Invalidate();

                                    }
                                    else if (players.Count == 1)
                                    {
                                        start.Enabled = false;

                                        players.Remove(playerToRemove);
                                        maze.Controls.Remove(playerToRemove);
                                        maze.Controls.Remove(circle);
                                        maze.Invalidate();
                                        //players.Clear();
                                        //maze.Controls.Remove(circle);
                                        //maze.Invalidate();
                                        con.send(Commands.CreateMessage(Commands.Logout, Commands.None, null));
                                        //  DialogResult result1 = MessageBox.Show("Disconnected", "Disconnected", MessageBoxButtons.OK);
                                        //if (result1 == DialogResult.OK)
                                        //{

                                        //   RequestName rn = new RequestName();
                                        // rn.Show();
                                        Close();
                                        //


                                    }


                                    start.Enabled = false;
                                    Player.canStart = false;
                                    chatField.Text += message.Data + " has logout.\r\n";
                                    break;

                            }
                            break;
                        case Commands.Disconnect:
                            userlist.Items.Remove(message.Data);
                            chatField.Text += message.Data + " lost connection.\r\n";
                            break;

                        case Commands.PublicMessage:
                            chatField.Text += message.Data + "\r\n";

                            chatField.SelectionStart = chatField.TextLength;
                            chatField.ScrollToCaret();
                            break;

                        case Commands.UserMoved:
                            Console.WriteLine("User moved");

                            foreach (Player player in players)
                            {
                                if (player.userName == message.User)
                                {
                                    player.Location = new Point(int.Parse(message.XPosition), int.Parse(message.YPosition));
                                    break;
                                }
                            }
                            //if (message.User == me && (new Point(int.Parse(message.XPosition), int.Parse(message.YPosition))) == maze.treasure)
                            //{
                            //    UpdateLabel("found");
                            //}


                            break;
                        case Commands.ScoreChanged:
                            Console.WriteLine("Score changed");
                            foreach (Player player in players)
                            {
                                if (player.userName == message.User)
                                {
                                    player.score = int.Parse(message.Data);
                                    break;
                                }
                            }
                            break;
                        case Commands.RoomBusy:
                            Console.WriteLine("Room Busy");
                            start.Enabled = false;
                            Player.canStart = true;
                            break;
                        case Commands.GetMaze:
                            Dictionary<string, int[,]> a = JsonConvert.DeserializeObject<Dictionary<string, int[,]>>(message.Data);
                            Console.WriteLine(message.Data);

                            if (!mazeReceived)
                            {
                                mazeReceived = true;
                                mazeMatrix = a["maze"];
                                maze = new Maze(mazeMatrix);
                                maze.MouseHover += ChatBox_MouseHover;
                                maze.MouseMove += ChatBox_MouseHover;
                                maze.MouseEnter += ChatBox_MouseHover;
                                maze.MouseLeave += ChatBox_MouseLeave;
                                Controls.Add(maze);
                            }

                            break;
                        case Commands.TreasureFound:
                            Console.WriteLine("Treasure found");
                            // start.Enabled = true;
                            Player.canStart = false;
                            int result = UpdateLabel("found");

                            //      con.send(Commands.CreateMessage(Commands.Logout, Commands.None, null));
                            Close();
                            if (result == 0)
                            {
                                //    con.send(Commands.CreateMessage(Commands.Logout, Commands.None, null));
                                //    // Application.Run(new RequestName());
                                //  Close();

                            }
                            break;

                    }
                }
            }
        }

        private void con_OnReceiveCompleted(object sender, ReceiveCompletedEventArgs args)
        {
            string text = Encoding.Unicode.GetString(args.data);
            BeginInvoke(new ReceiveFunctionCall(ReceieveMessage), text);
        }

        private void sendMessage(string command, string user)
        {
            byte[] data = Commands.CreateMessage(command, Commands.None, txtChat.Text, user);

            con.send(data);

            txtChat.Text = "";
            sendBtn.Enabled = false;
        }

        private void sendBtn_Click(object sender, EventArgs e)
        {
            handleFocus(false);
            sendMessageHandler();

        }

        private void sendMessageHandler()
        {

            if (userlist.SelectedItems.Count > 0)
            {
                switch (userlist.SelectedItem.ToString())
                {
                    case "All users":
                        sendMessage(Commands.PublicMessage, null);
                        break;
                    default:
                        sendMessage(Commands.PrivateMessage, userlist.SelectedItem.ToString());
                        break;
                }
            }
            else { sendMessage(Commands.PublicMessage, null); }
        }

        private void txtChat_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtChat.Text == "" && sendBtn.Enabled)
            {
                sendBtn.Enabled = false;
            }
            else if (txtChat.Text != "" && !sendBtn.Enabled)
            {
                sendBtn.Enabled = true;
            }
        }

        private void ChatBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.send(Commands.CreateMessage(Commands.Logout, Commands.None, null));
            //con.close();
            Application.Exit();
        }

        private void txtChat_TextChanged(object sender, EventArgs e)
        {
            handleFocus(false);
        }

        private void txtChat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                sendMessageHandler();
            }
        }

        private void chatField_TextChanged(object sender, EventArgs e)
        {

        }

        private void userlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (players.Count > 0)
            //{
            //    players[0].InFocus = false;
            //}
            handleFocus(false);
        }

        private void userlist_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
        }

        private void txtChat_Click(object sender, EventArgs e)
        {
            //if (players.Count == 1)
            //{
            //    players[0].InFocus = false;

            //}
            handleFocus(false);
        }

        private void userlist_Click(object sender, EventArgs e)
        {
            //if (players.Count == 1)
            //{
            //    players[0].InFocus = false;

            //}
            handleFocus(false);
        }
        private void handleFocus(bool value)
        {
            if (players.Count > 0 && circle != null)
            {
                circle.InFocus = value;
                if (value == true) { circle.Focus(); }
            }
        }

        private void start_Click(object sender, EventArgs e)
        {

            byte[] data = Commands.CreateMessage(Commands.RoomBusy, Commands.None, room);

            con.send(data);

        }

        public static int UpdateLabel(string text)
        {
            if (text.Contains("found"))
            {
                treasureHints.Text = "Treasure found";
                int totalScore = 0;
                string message = "Scoreboard " + meStatic + "\n";
                List<Player> playersOrdered = players.OrderByDescending(player => player.score).ToList();
                if (meStatic == playersOrdered[0].userName) { message += "\nWinner!!!\n"; }
                else
                {
                    message += "\nMaybe next time!!!\n";
                }

                foreach (Player player in playersOrdered)
                {
                    totalScore += player.score;
                    if (meStatic == player.userName)
                    {
                        message += player.userName + ": " + player.score + "\n";
                    }
                    else
                    {
                        message += player.userName + ": " + player.score + "\n";
                    }
                    // Player.canStart = false;
                }


                message += "\n" + "Total score: " + totalScore + "\n";

                DialogResult result = MessageBox.Show(message, "Scoreboard " + meStatic, MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly); ;
                if (result == DialogResult.OK)
                {
                    return 1;
                }

            }

            treasureHints.Text = text;
            Timer timer = new Timer
            {
                Interval = 5000 // set the interval to 10 second
            };
            timer.Tick += (s, e) =>
            {
                treasureHints.Text = "Find the treasure!";
                timer.Stop();
                timer.Dispose();
            };
            timer.Start();
            return 0;
        }

        public static void UpdateScore(int value)
        {
            score.Text = "Score: " + value.ToString();
        }
    }
}
