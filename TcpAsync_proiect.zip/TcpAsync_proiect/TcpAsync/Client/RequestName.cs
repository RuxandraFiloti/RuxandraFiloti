﻿using Connection;
using Newtonsoft.Json;
using Server;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class RequestName : Form
    {
        private readonly TCPConnection con;
        private bool connected;
        private readonly int server_port = 7755;

        public RequestName()
        {
            InitializeComponent();
            con = new TCPConnection();
            con.OnConnectCompleted += con_OnConnectCompleted;
            con.OnExceptionRaised += con_OnExceptionRaised;

            connected = false;
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            string uname = username.Text;
            string serverip = server.Text;

            if (uname.Trim() == "")
            {
                MessageBox.Show("Please fill your name first.");
            }
            else if (!IPAddress.TryParse(serverip, out IPAddress servAddr))
            {
                MessageBox.Show("Invalid server address.");
            }
            else
            {
                Dictionary<string, string> map = new Dictionary<string, string>
                    {
                        { "user", username.Text },
                        { "observer", checkBox1.Checked.ToString() },
                        { "room", room.Text }
                    };
                string json = JsonConvert.SerializeObject(map);
                if (connected)
                {
                    con.send(Commands.CreateMessage(Commands.ValidateUsername, Commands.Request, json, room.Text));
                }
                else
                {
                    con.connect(new IPEndPoint(servAddr, server_port));
                    con.send(Commands.CreateMessage(Commands.ValidateUsername, Commands.Request, json, room.Text));
                }
            }
        }

        private delegate void FormFunctionCall();
        public void OpenChatBox()
        {
            ChatBox cb = new ChatBox(con, username.Text, room.Text)
            {
                Text = "ChatBox - " + username.Text + " " + room.Text
            };
            cb.Show();
            Hide();
        }

        private delegate void ReceiveFunctionCall(string text);
        private string incompleteMessage = null;
        private void ReceieveMessage(string text)
        {

            if (incompleteMessage != null)
            {
                text = incompleteMessage + text;
            }

            //chatField.Text += text + "\r\n";

            //chatField.SelectionStart = chatField.TextLength;
            //chatField.ScrollToCaret();

            string[] messages = text.Split(new string[] { Commands.EndMessageDelim }, StringSplitOptions.RemoveEmptyEntries);

            if (messages.Length > 0)
            {
                //verifies if last message is complete (correction = 0)
                //if not (correction = 1) it will be stored for further use
                int correction = (text.EndsWith(Commands.EndMessageDelim) ? 0 : 1);
                if (correction == 1)
                {
                    incompleteMessage = messages[messages.Length - 1];
                }
                else
                {
                    incompleteMessage = null;
                }

                for (int i = 0; i < messages.Length - correction; i++)
                {
                    Commands.Message message = Commands.DecodeMessage(messages[i]);

                    switch (message.Command)
                    {
                        case Commands.ValidateUsername:
                            if (message.Subcommand == Commands.Accept)
                            {
                                con.send(Commands.CreateMessage(Commands.Connect, Commands.Request, null, "user", room.Text));
                            }
                            else
                            {
                                if (message.Data == null || message.Data == Commands.None)
                                {
                                    MessageBox.Show("Username unavailable.");
                                }
                                else { MessageBox.Show(message.Data); }
                                con.send(Commands.CreateMessage(Commands.ValidateUsername, Commands.Deny, null));

                            }
                            break;

                        case Commands.Connect:
                            con.OnReceiveCompleted -= con_OnReceiveCompleted;
                            BeginInvoke(new FormFunctionCall(OpenChatBox));
                            break;
                    }
                }
            }
        }

        private void con_OnExceptionRaised(object sender, ExceptionRaiseEventArgs args)
        {
            Exception exc = args.raisedException;
            MessageBox.Show(exc.Message);
        }

        private void con_OnConnectCompleted(object sender, EventArgs args)
        {
            connected = true;
            con.OnReceiveCompleted += con_OnReceiveCompleted;
        }

        private void con_OnReceiveCompleted(object sender, ReceiveCompletedEventArgs args)
        {
            string text = Encoding.Unicode.GetString(args.data);
            BeginInvoke(new ReceiveFunctionCall(ReceieveMessage), text);
        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
