﻿using Connection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Server
{
    internal class Program
    {

        public static readonly int[,] maze = new int[,] {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 0, 1, 1, 0, 1, 1, 1, 0},
        {0, 1, 1, 1, 1, 1, 1, 0, 1, 0},
        {0, 1, 1, 0, 1, 1, 0, 0, 1, 0},
        {0, 1, 1, 0, 0, 0, 1, 1, 1, 0},
        {0, 1, 0, 1, 1, 1, 1, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 1, 1, 1, 0},
        {0, 1, 0, 1, 1, 0, 1, 0, 1, 0},
        {0, 1, 1, 0, 0, 1, 1, 1, 1, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };
        public static readonly List<Point> track = new List<Point>();
        public static List<Room> rooms = new List<Room>();
        private static readonly int server_port = 7755;

        private static readonly Dictionary<string, User> userlist = new Dictionary<string, User>();
        private static readonly TCPConnection con = new TCPConnection();
        private static readonly Random random = new Random();
        private static void Main(string[] args)
        {
            con.reserve(server_port);
            con.OnReceiveCompleted += con_OnReceiveCompleted;
            con.OnExceptionRaised += con_OnExceptionRaised;
            createTrack();

            System.Threading.Thread.Sleep(System.Threading.Timeout.Infinite);
        }

        public static void createTrack()
        {
            for (int i = 0; i < maze.GetLength(0); i++)
            {
                for (int j = 0; j < maze.GetLength(1); j++)
                {
                    int x = j * 50;
                    int y = i * 50;

                    switch (maze[i, j])
                    {
                        case 1:
                            //track.Add(new Point(x + 50, y + 100));
                            //      Console.WriteLine("Point added: " + x + " " + y); 
                            track.Add(new Point(x, y));
                            break;

                    }

                }
            }

        }


        private static void con_OnExceptionRaised(object sender, ExceptionRaiseEventArgs args)
        {
            if (sender is Socket)
            {
                try
                {
                    Socket sock = sender as Socket;
                    IPEndPoint iep = (sock.RemoteEndPoint as IPEndPoint);
                    string clientAddr = iep.Address.ToString() + iep.Port;

                    if (userlist.ContainsKey(clientAddr))
                    {
                        string uname = userlist[clientAddr].Username;
                        Console.WriteLine(uname + " lost connection.");

                        con.send(Commands.CreateMessage(Commands.Disconnect, Commands.None, uname));
                        con.close(sock);
                        userlist.Remove(clientAddr);
                    }
                    else
                    {
                        Console.WriteLine(clientAddr + " lost connection."); // unknown username
                    }
                }
                catch (ObjectDisposedException) { }
            }
            else
            {
                if (!(sender.GetType() == typeof(Socket)))
                {
                    Console.WriteLine("exception source : " + args.raisedException.Source);
                    Console.WriteLine("exception raised : " + args.raisedException.Message);
                    Console.WriteLine("exception detail : " + args.raisedException.InnerException);
                }
            }
        }

        private static void con_OnReceiveCompleted(object sender, ReceiveCompletedEventArgs rdArgs)
        {
            byte[] recData = rdArgs.data;
            IPEndPoint iep = (rdArgs.remoteSock.RemoteEndPoint as IPEndPoint);
            string clientAddr = iep.Address.ToString() + iep.Port;

            if (!userlist.ContainsKey(clientAddr))
            {
                int index = random.Next(track.Count - 1);
                userlist[clientAddr] = new User
                {
                    Color = Color.FromArgb(255, random.Next(0, 255), random.Next(0, 255), random.Next(0, 255)),
                    //     Point = new Point(track[index].X, track[index].Y)
                };

                Console.WriteLine("User added: ");
            }

            User user = userlist[clientAddr];

            string text = Encoding.Unicode.GetString(recData);

            if (user.IncompleteMessage != null)
            {
                text = user.IncompleteMessage + text;
            }

            Console.WriteLine(text + "\r\n");

            string[] messages = text.Split(new string[] { Commands.EndMessageDelim }, StringSplitOptions.RemoveEmptyEntries);

            if (messages.Length > 0)
            {
                //verifies if last message is complete (correction = 0)
                //if not (correction = 1) it will be stored for further use
                int correction = (text.EndsWith(Commands.EndMessageDelim) ? 0 : 1);
                if (correction == 1)
                {
                    user.IncompleteMessage = messages[messages.Length - 1];
                }
                else
                {
                    user.IncompleteMessage = null;
                }

                for (int i = 0; i < messages.Length - correction; i++)
                {
                    Commands.Message message = Commands.DecodeMessage(messages[i]);

                    switch (message.Command)
                    {
                        case Commands.Logout:
                            string uname = userlist[clientAddr].Username;
                            Console.WriteLine(uname + " logout successfully.");

                            con.close(rdArgs.remoteSock);
                            string roomName = user.Room.Name;
                            int nr = 0;
                            foreach (KeyValuePair<string, User> u in userlist)
                            {
                                if (u.Value.Room.Name == roomName && !u.Value.IsObserver)
                                {
                                    nr++;
                                }
                            }

                            userlist.Remove(clientAddr);
                            if (user.IsObserver)
                            {
                                con.send(Commands.CreateMessage(Commands.UserList, Commands.Remove, uname), user.Room.Name);

                                break;
                            }
                            if (nr == 2)
                            {
                                rooms.Remove(rooms.Find(r => r.Name == roomName));

                                foreach (KeyValuePair<string, User> u in userlist)
                                {
                                    if (u.Value.Status != User.StatusType.UsernameInvalid && u.Value.Room.Name == roomName)
                                    {
                                        con.send(Commands.CreateMessage(Commands.UserList, Commands.Remove, u.Value.Username), user.Room.Name);


                                    }
                                }
                            }
                            Room room1 = rooms.Find(r => r.Name == roomName);
                            if (nr == 1 && room1 != null)
                            {
                                rooms.Remove(room1);
                            }
                            if (nr == 1)
                            {
                                //    rooms.Remove(rooms.Find(r => r.Name == roomName));
                                //    con.send(Commands.CreateMessage(Commands.UserList, Commands.Remove, uname), user.Room.Name);
                                //    con.removeRoom(roomName);
                                con.removeRoom(roomName);
                                break;

                            }


                            con.send(Commands.CreateMessage(Commands.UserList, Commands.Remove, uname), user.Room.Name);


                            break;
                        //case Commands.LogoutAll:
                        //    string uname = userlist[clientAddr].Username;
                        //    Console.WriteLine(uname + " logout successfully.");

                        //    con.close(rdArgs.remoteSock);
                        //    string roomName = user.Room.Name;
                        //    foreach (KeyValuePair<string, User> u in userlist)
                        //    {
                        //        if (u.Value.Room.Name == roomName)
                        //        {
                        //            nr++;
                        //        }
                        //    }

                        //    userlist.Remove(clientAddr);
                        //    if (nr == 1) { rooms.Remove(rooms.Find(r => r.Name == roomName)); }

                        //    con.send(Commands.CreateMessage(Commands.UserList, Commands.Remove, uname), user.Room.Name);
                        //    break;
                        case Commands.ValidateUsername:
                            if (message.Subcommand == Commands.Request)
                            {
                                bool usernameExists = false;
                                Dictionary<string, string> dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(message.Data);

                                userlist[clientAddr].IsObserver = bool.Parse(dict["observer"]);
                                foreach (KeyValuePair<string, User> u in userlist)
                                {
                                    if (u.Value.Status != User.StatusType.UsernameInvalid && u.Value.Username == dict["user"])
                                    {
                                        usernameExists = true;
                                        break;
                                    }
                                }
                                if (!usernameExists)
                                {
                                    user.Username = dict["user"];
                                    user.Status = User.StatusType.Connecting;
                                    if (dict["observer"] == "True")
                                    {

                                        if (rooms.Find(r => r.Name == dict["room"]) == null)
                                        {
                                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.ValidateUsername, Commands.Deny, "RoomDoesNotExist"), rdArgs.remoteSock);
                                            user.Status = User.StatusType.UsernameInvalid;
                                            break;
                                        }

                                        con.sendBySpecificSocket(Commands.CreateMessage(Commands.ValidateUsername, Commands.Accept, user.Username, message.User, message.Room), rdArgs.remoteSock);
                                        break;

                                    }
                                    else if (dict["observer"] == "False")
                                    {
                                        Room room = rooms.Find(r => r.Name == dict["room"]);

                                        if (room != null && room.isBusy)
                                        {
                                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.ValidateUsername, Commands.Deny, "RoomBusy"), rdArgs.remoteSock);

                                            break;
                                        }
                                    }

                                    con.sendBySpecificSocket(Commands.CreateMessage(Commands.ValidateUsername, Commands.Accept, user.Username, message.User, message.Room), rdArgs.remoteSock);

                                    break;
                                }
                            }
                            else if (message.Subcommand == Commands.Deny)
                            {
                                userlist.Remove(clientAddr);
                                break;
                            }

                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.ValidateUsername, Commands.Deny, null), rdArgs.remoteSock);
                            user.Status = User.StatusType.UsernameInvalid;
                            break;

                        case Commands.Connect:

                            if (user.Status != User.StatusType.Connecting)
                            {
                                Console.WriteLine("Connecting to room: " + message.Room);
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }

                            if (message.Subcommand == Commands.Request)
                            {
                                Console.WriteLine("Connect to room: " + message.Room);
                                // userlist[clientAddr].Room.Name = message.Room;
                                //  user.Room.Name = message.Room;
                                if (rooms.Count > 0)
                                {
                                    Room room = rooms.Find(r => r.Name == message.Room);
                                    if (room == null)
                                    {
                                        Room roomToAdd = new Room(message.Room);
                                        userlist[clientAddr].Room = roomToAdd;
                                        rooms.Add(roomToAdd);
                                    }
                                    else { userlist[clientAddr].Room = room; }
                                }
                                else
                                {
                                    Room roomToAdd = new Room(message.Room);
                                    userlist[clientAddr].Room = roomToAdd;
                                    rooms.Add(roomToAdd);
                                }
                                userlist[clientAddr].Point = user.Room.Track[random.Next(user.Room.Track.Count - 1)];

                                user.Status = User.StatusType.Connected;
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.Connect, Commands.Accept, null), rdArgs.remoteSock, "0", message.Room);
                            }
                            break;

                        case Commands.UserList:
                            if (user.Status != User.StatusType.Connected)
                            {
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }

                            foreach (KeyValuePair<string, User> u in userlist)
                            {
                                if (u.Value.Username != user.Username && u.Value.Room.Name == user.Room.Name)
                                {
                                    byte[] data = Commands.CreateMessage(Commands.UserList, Commands.Add, null, u.Value.Username, user.Room.Name,
                                        u.Value.Point.X.ToString(), u.Value.Point.Y.ToString(),
                                        u.Value.Color.R.ToString(), u.Value.Color.G.ToString(), u.Value.Color.B.ToString());
                                    //Add all the current users to the new user
                                    Console.WriteLine(Encoding.Unicode.GetString(data));
                                    con.sendBySpecificSocket(data, rdArgs.remoteSock);
                                }
                            }
                            //Add current user to all others
                            con.send(Commands.CreateMessage(Commands.UserList, Commands.Add, user.IsObserver.ToString(), user.Username, user.Room.Name,
                                user.Point.X.ToString(), user.Point.Y.ToString(),
                                        user.Color.R.ToString(), user.Color.G.ToString(), user.Color.B.ToString()
                                ), user.Room.Name);
                            Console.WriteLine(clientAddr.ToLowerInvariant());
                            Console.WriteLine(user.Username + " has joined this conversation.");
                            break;
                        case Commands.UserMoved:
                            if (user.Status != User.StatusType.Connected)
                            {
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }

                            //  foreach (KeyValuePair<string, User> u in userlist)
                            //  {
                            //if (u.Value.Username != user.Username && u.Value.Room == user.Room)
                            //{
                            //    byte[] data = Commands.CreateMessage(Commands.UserList, Commands.Add, null, u.Value.Username, user.Room,
                            //        u.Value.Point.X.ToString(), u.Value.Point.Y.ToString(),
                            //        u.Value.Color.R.ToString(), u.Value.Color.G.ToString(), u.Value.Color.B.ToString());
                            //    //Add all the current users to the new user
                            //    Console.WriteLine(Encoding.Unicode.GetString(data));
                            //    con.sendBySpecificSocket(data, rdArgs.remoteSock);
                            //}
                            //     }
                            //Add current user to all others
                            userlist[clientAddr].Point = new Point(int.Parse(message.XPosition), int.Parse(message.YPosition));
                            user = userlist[clientAddr];
                            con.send(Commands.CreateMessage(Commands.UserMoved, Commands.Add, null, user.Username, user.Room.Name,
                                user.Point.X.ToString(), user.Point.Y.ToString(),
                                        user.Color.R.ToString(), user.Color.G.ToString(), user.Color.B.ToString()
                                ), user.Room.Name);
                            Console.WriteLine(clientAddr.ToLowerInvariant());
                            Console.WriteLine(user.Username + " has moved.");
                            break;
                        case Commands.ScoreChanged:
                            if (user.Status != User.StatusType.Connected)
                            {
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }
                            //Add current user to all others
                            userlist[clientAddr].Score = int.Parse(message.Data);
                            user = userlist[clientAddr];
                            con.send(Commands.CreateMessage(Commands.ScoreChanged, Commands.None, user.Score.ToString(), user.Username, user.Room.Name,
                                user.Point.X.ToString(), user.Point.Y.ToString(),
                                        user.Color.R.ToString(), user.Color.G.ToString(), user.Color.B.ToString()
                                ), user.Room.Name);
                            Console.WriteLine(clientAddr.ToLowerInvariant());
                            Console.WriteLine(user.Username + " score changed.");
                            break;
                        case Commands.RoomBusy:
                            rooms.Find(room => room.Name == message.Data).isBusy = true;
                            con.send(Commands.CreateMessage(Commands.RoomBusy, Commands.Add, null), user.Room.Name);
                            //   Console.WriteLine(clientAddr.ToLowerInvariant());
                            Console.WriteLine(message.Data + "Room is busy");
                            break;
                        case Commands.GetMaze:

                            Dictionary<string, int[,]> a = new Dictionary<string, int[,]>
                            {
                                { "maze", user.Room.Maze }
                            };
                            string jsonMaze = JsonConvert.SerializeObject(a);
                            con.send(Commands.CreateMessage(Commands.GetMaze, Commands.None, jsonMaze), user.Room.Name);
                            break;
                        case Commands.TreasureFound:

                            con.send(Commands.CreateMessage(Commands.TreasureFound, Commands.None, null), user.Room.Name);
                            //   Console.WriteLine(clientAddr.ToLowerInvariant());
                            Console.WriteLine("Treasure Found");

                            break;
                        case Commands.PublicMessage:

                            if (user.Status != User.StatusType.Connected)
                            {
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }

                            string updateMessage = userlist[clientAddr].Username + " says : " + message.Data;

                            con.send(Commands.CreateMessage(Commands.PublicMessage, Commands.None, updateMessage), user.Room.Name);
                            break;
                        case Commands.PrivateMessage:

                            if (user.Status != User.StatusType.Connected)
                            {
                                con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Invalid request for current state."), rdArgs.remoteSock);
                            }
                            string toUser = null;
                            string updateMessage1 = userlist[clientAddr].Username + " says : " + message.Data + " to " + message.User;
                            foreach (string u in userlist.Keys)
                            {
                                if (userlist[u].Username == message.User)
                                {

                                    toUser = u;
                                }
                            }

                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.PrivateMessage, Commands.None, updateMessage1), rdArgs.remoteSock, toUser);

                            break;

                        case Commands.MalformedCommand:
                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.MalformedCommand, Commands.None, null), rdArgs.remoteSock);
                            break;

                        default:
                            con.sendBySpecificSocket(Commands.CreateMessage(Commands.InvalidRequest, Commands.None, "Unknown command."), rdArgs.remoteSock);
                            break;
                    }
                }
            }
        }
    }
}
