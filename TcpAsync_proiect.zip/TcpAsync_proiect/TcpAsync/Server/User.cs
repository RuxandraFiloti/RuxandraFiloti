﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Sockets;

namespace Server
{
    public class User
    {
        public enum StatusType
        {
            UsernameInvalid,
            RoomInvalid,
            Connecting,
            Connected
        }

        public string Username { get; set; }
        public StatusType Status { get; set; }
        public string IncompleteMessage { get; set; }
        public Socket UserSocket { get; set; }
        public Room Room { get; set; }

        public Point Point { get; set; }
        public Color Color { get; set; }
        public bool IsObserver { get; set; }
        public int Score { get; set; }
        public User(string username, Socket userSocket)
        {
            Username = username;
            UserSocket = userSocket;
            Status = StatusType.Connecting;
            IncompleteMessage = null;
            Room = null;
            Color = Color.White;
            Point = new Point();
            Score = 0;
            IsObserver = false;
        }

        public User()
        {
            Username = null;
            Status = StatusType.UsernameInvalid;
            IncompleteMessage = null;
            Room = null;
            Color = Color.White;
            Point = new Point();
            Score = 0;
            IsObserver = false;
        }
    }

    public class Room
    {
        public string Name { get; set; }
        public bool isBusy { get; set; }
        public static int[] values = new int[] { 0, 1 };
        public static int[] hintsBonusValues = new int[] { 7, 3 };
        public static Random Random = new Random();
        public int[,] Maze;
        public List<Point> Track = new List<Point>();
        public Point Treasure { get; set; }
        public Room(string name)
        {
            Name = name;
            isBusy = false;
            Maze = GetRandomMaze();
            createTrack();
            Treasure = new Point(Random.Next(Maze.GetLength(0) - 1), Random.Next(Maze.GetLength(1) - 1));
            Maze[Treasure.X, Treasure.Y] = 9;
            Console.WriteLine("Treasure" + Name + " " + Treasure.ToString());
        }

        public static int GetRandomValue()
        {
            return values[Random.Next(values.Length)];
        }

        public static int GetRandomBonus()
        {
            return hintsBonusValues[Random.Next(hintsBonusValues.Length)];
        }

        public static int[,] GetRandomMaze()
        {
            int[,] maze = new int[,] {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0},
        {0, 1, GetRandomValue(), 1, 1, 0, 1, 7, GetRandomValue(), 0,0},
        {0, GetRandomBonus(), 1, 1, GetRandomBonus(), 1, GetRandomBonus(), 0, GetRandomBonus(), 1,0},
        {0, 1, GetRandomBonus(), 1, 1, GetRandomValue(), GetRandomValue(), 0, 1, GetRandomBonus(),0},
        {0, 1, 1, 1, 0, 1, 1, 1, 1, 0,0},
        {0, 1, GetRandomValue(), 1, 1, 1, 1, 0, 0, 0,0},
        {0, 0, GetRandomBonus(), 1, GetRandomValue(), 0, GetRandomBonus(), 1, 1, GetRandomBonus(),0},
        {0, 1, GetRandomBonus(), GetRandomBonus(), 7, GetRandomValue(), 1, 0, GetRandomBonus(), GetRandomBonus(),0},
        {0, 1, GetRandomBonus(), 1, 1, GetRandomBonus(), 1, GetRandomBonus(), 1, 0,0},
        {0, 1, 1, GetRandomBonus(), 0, GetRandomBonus(), 1, GetRandomBonus(), 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        };
            return maze;

        }

        public void createTrack()
        {
            for (int i = 0; i < Maze.GetLength(0); i++)
            {
                for (int j = 0; j < Maze.GetLength(1); j++)
                {
                    int x = j * 50;
                    int y = i * 50;

                    switch (Maze[i, j])
                    {
                        case 0:
                            //track.Add(new Point(x + 50, y + 100));
                            //      Console.WriteLine("Point added: " + x + " " + y); 
                            break;
                        default: Track.Add(new Point(x, y)); break;

                    }

                }
            }

        }
    }
}
