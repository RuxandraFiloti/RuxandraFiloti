﻿using IConnection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;

namespace Connection
{
    public class TCPConnection : IConnection
    {
        private const int BUFFER = 8192;
        private Socket localSocket = null;
        private List<Socket> clientList = null;
        private readonly List<Room> rooms = new List<Room>();
        public bool connect(IPEndPoint remoteEndpoint)
        {
            try
            {
                localSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                ConnectionObject co = new ConnectionObject
                {
                    workingBytes = new byte[BUFFER],
                    clientSocket = localSocket
                };

                localSocket.BeginConnect(remoteEndpoint, new AsyncCallback(OnConnect), co);

                return true;
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        public bool reserve(int port)
        {
            try
            {
                clientList = new List<Socket>();
                localSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint localEndpoint = new IPEndPoint(IPAddress.Any, port);

                ConnectionObject co = new ConnectionObject
                {
                    workingBytes = new byte[BUFFER]
                };

                localSocket.Bind(localEndpoint);
                localSocket.Listen(100);
                localSocket.BeginAccept(new AsyncCallback(OnAccept), co);

                return true;
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        public bool send(byte[] data, string room = null)
        {

            try
            {
                if (localSocket == null)
                {
                    return false;
                }
                else
                {
                    ConnectionObject co = new ConnectionObject
                    {
                        workingBytes = data,
                        clientSocket = localSocket
                    };

                    if (clientList == null)
                    {
                        localSocket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(OnSend), co);
                    }
                    else
                    {
                        if (room != null)
                        {
                            Room room1 = rooms.Find(r => r.Name == room);
                            if (room1 != null)
                            {
                                foreach (Socket client in room1.Sockets)
                                {
                                    co = new ConnectionObject
                                    {
                                        workingBytes = data,
                                        clientSocket = client
                                    };
                                    client.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(OnSend), co);
                                }
                            }
                        }
                        else
                        {
                            foreach (Socket client in clientList)
                            {
                                co = new ConnectionObject
                                {
                                    workingBytes = data,
                                    clientSocket = client
                                };
                                client.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(OnSend), co);
                            }
                        }

                    }
                }

                return true;
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        public bool sendBySpecificSocket(byte[] data, Socket sockAddr, string addr = "0", string room = null)
        {
            try
            {
                Socket s = sockAddr;
                if (addr == "0" || addr == null) { s = sockAddr; }
                else
                {
                    foreach (Socket client in clientList)
                    {
                        Console.WriteLine("Addr: " + client.RemoteEndPoint.ToString().Replace(":", "") + " " + addr);
                        if (addr == client.RemoteEndPoint.ToString().Replace(":", "")) { s = client; break; }
                    }

                }
                ConnectionObject co = new ConnectionObject
                {
                    workingBytes = data,
                    clientSocket = s
                };
                if (room != null)
                {
                    if (rooms.Count == 0)
                    {
                        rooms.Add(new Room(room));
                        rooms[0].Sockets.Add(s);
                    }
                    else
                    {
                        bool roomExist = false;
                        for (int i = 0; i < rooms.Count; i++)
                        {
                            if (rooms[i].Name.Equals(room))
                            {
                                rooms[i].Sockets.Add(s);
                                roomExist = true;
                                break;
                            }
                        }
                        if (!roomExist)
                        {
                            rooms.Add(new Room(room, s));
                        }
                    }
                }

                s.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(OnSend), co);

                return true;
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        public bool close()
        {
            try
            {
                localSocket.Close();

                return false;
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        public bool close(Socket sock)
        {
            try
            {
                sock.Close(100);
                removeUnusedSocket();
                return false;
            }
            catch (Exception exc)
            {
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                return false;
            }
        }

        // tcp async call back
        private void OnAccept(IAsyncResult ar)
        {
            try
            {
                if (ar.IsCompleted)
                {
                    ConnectionObject recObj = ar.AsyncState as ConnectionObject;
                    recObj.clientSocket = localSocket.EndAccept(ar);
                    localSocket.BeginAccept(new AsyncCallback(OnAccept), recObj);

                    ConnectionObject co = new ConnectionObject
                    {
                        workingBytes = new byte[BUFFER],
                        clientSocket = recObj.clientSocket
                    };

                    clientList.Add(recObj.clientSocket);
                    recObj.clientSocket.BeginReceive(
                        co.workingBytes,
                        0,
                        co.workingBytes.Length,
                        SocketFlags.None, new AsyncCallback(OnReceive),
                        co);
                }
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
            }
        }

        private void OnSend(IAsyncResult ar)
        {

            try
            {
                if (ar.IsCompleted)
                {

                    ConnectionObject sendObj = ar.AsyncState as ConnectionObject;
                    sendObj.clientSocket.EndSend(ar);
                }
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
            }
        }

        private void OnReceive(IAsyncResult ar)
        {

            try
            {
                if (ar.IsCompleted)
                {
                    ConnectionObject recObj = ar.AsyncState as ConnectionObject;

                    Socket workingSock = recObj.clientSocket;

                    int receivedBytes = workingSock.EndReceive(ar);
                    byte[] recBytes = recObj.workingBytes.Take(receivedBytes).ToArray();

                    ReceiveCompleted(this, new ReceiveCompletedEventArgs(recBytes, workingSock));

                    ConnectionObject co = new ConnectionObject
                    {
                        workingBytes = new byte[BUFFER],
                        clientSocket = workingSock
                    };

                    workingSock.BeginReceive(co.workingBytes, 0, co.workingBytes.Length, SocketFlags.None, new AsyncCallback(OnReceive), co);
                }
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ConnectionObject recObj = ar.AsyncState as ConnectionObject;
                if (recObj.clientSocket == default(Socket))
                {
                    ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
                }
                else
                {
                    ExceptionRaised(recObj.clientSocket, new ExceptionRaiseEventArgs(exc));
                }
            }
        }

        private void OnConnect(IAsyncResult ar)
        {
            try
            {
                ConnectionObject recObj = ar.AsyncState as ConnectionObject;
                localSocket.EndConnect(ar);

                ConnectionObject co = new ConnectionObject
                {
                    workingBytes = new byte[BUFFER],
                    clientSocket = localSocket
                };

                ConnectCompleted(this, null);
                localSocket.BeginReceive(co.workingBytes, 0, co.workingBytes.Length, SocketFlags.None, new AsyncCallback(OnReceive), co);
            }
            catch (Exception exc)
            {
                removeUnusedSocket();
                ExceptionRaised(this, new ExceptionRaiseEventArgs(exc));
            }
        }

        private void removeUnusedSocket()
        {
            if (clientList != null)
            {
                foreach (Socket client in clientList)
                {
                    if (!client.Connected)
                    {
                        int index = -1;
                        clientList.Remove(client);
                        foreach (Room room in rooms)
                        {
                            foreach (Socket socket in room.Sockets)
                            {
                                if (socket.Equals(client)) { index = rooms.IndexOf(room); }
                            }
                        }
                        if (index > -1)
                        {
                            rooms[index].Sockets.Remove(client);
                            //if (rooms[index].Sockets.Count == 1)
                            //{
                            //    rooms.Remove(rooms[index]);
                            //}
                            //   if (rooms[index].Sockets.Count == 0) { rooms.Remove(rooms[index]); }
                        }

                        break;
                    }
                }
            }
        }

        public void removeRoom(string name)
        {
            Room r = rooms.Find(x => x.Name == name);
            if (r != null)
            {
                rooms.Remove(r);
            }
        }

        public delegate void ConnectCompletedHandler(object sender, EventArgs args);
        public event ConnectCompletedHandler OnConnectCompleted;
        private void ConnectCompleted(object sender, EventArgs args)
        {
            if (OnConnectCompleted != null)
            {
                OnConnectCompleted(sender, args);
            }
        }

        public delegate void ReceiveCompletedHandler(object sender, ReceiveCompletedEventArgs args);
        public event ReceiveCompletedHandler OnReceiveCompleted;
        private void ReceiveCompleted(object sender, ReceiveCompletedEventArgs args)
        {
            if (OnReceiveCompleted != null)
            {
                OnReceiveCompleted(sender, args);
            }
        }

        public delegate void ExceptionRaisedHandler(object sender, ExceptionRaiseEventArgs args);
        public event ExceptionRaisedHandler OnExceptionRaised;
        private void ExceptionRaised(object sender, ExceptionRaiseEventArgs args)
        {
            if (OnExceptionRaised != null)
            {
                OnExceptionRaised(sender, args);
            }
        }
    }
}
