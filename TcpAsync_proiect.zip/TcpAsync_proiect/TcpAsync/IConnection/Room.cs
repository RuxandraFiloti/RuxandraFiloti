﻿using System.Collections.Generic;
using System.Net.Sockets;

namespace IConnection
{
    internal class Room
    {
        public string Name { get; set; }
        public List<Socket> Sockets { get; set; }
        public static int Count = 0;
        public bool IsBusy = false;
        public Room(string name)
        {
            Name = name;
            Sockets = new List<Socket>();
        }

        public Room(string name, Socket socket)
        {
            Name = name;
            Sockets = new List<Socket>
            {
                socket
            };
        }

        public void AddUser(Socket user)
        {
            Sockets.Add(user);
        }

        public void RemoveUser(Socket user)
        {
            Sockets.Remove(user);
        }

        public bool ContainsUser(Socket user)
        {
            return Sockets.Contains(user);
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
