﻿using System.Net;
using System.Net.Sockets;

namespace Connection
{
    internal interface IConnection
    {
        bool close();
        bool close(Socket sock);
        bool connect(IPEndPoint remoteEndpoint);
        bool reserve(int port);
        bool send(byte[] data, string room);
        bool sendBySpecificSocket(byte[] data, Socket sockAddr, string addr, string room);
    }
}
