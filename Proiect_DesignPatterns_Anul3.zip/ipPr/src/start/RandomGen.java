/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.util.Random;

/**
 *
 * @author casap
 */
public class RandomGen
        extends Random
{

    public RandomGen()
    {
    }

    public static Random getInstance()
    {
        return RandomHolder.INSTANCE;
    }

    private static class RandomHolder
    {

        private static final Random INSTANCE = new Random();
    }
}
