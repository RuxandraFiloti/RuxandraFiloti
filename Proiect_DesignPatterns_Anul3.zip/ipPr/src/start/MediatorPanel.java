/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author casap
 */
public class MediatorPanel
        extends JPanel
{

    MyFrame frame;
    FlyWeightFactory fwf;
    ArrayList<Integer> in;
    int nr1 = 0;

    public MediatorPanel(MyFrame frame)
    {
        this.frame = frame;
        fwf = new FlyWeightFactory(this);
        this.setSize(frame.getSize());
        this.setLayout(null);
        this.setBackground(new Color(255, 245, 234));
        in = new ArrayList<>();
        in.add(120);
        in.add(240);
        in.add(360);
        in.add(480);
        fwf.addToPanel(new Point(in.get(nr1), 70));
        nr1++;
        fwf.addToPanel(new Point(in.get(nr1), 70));
        nr1++;
        fwf.addToPanel(new Point(in.get(nr1), 70));
        nr1++;
        fwf.addToPanel(new Point(in.get(nr1), 70));
        nr1++;
    }
}
