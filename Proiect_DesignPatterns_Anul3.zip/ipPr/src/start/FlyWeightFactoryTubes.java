/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author casap
 */
public class FlyWeightFactoryTubes
        extends JPanel
{

    MediatorPanel mp;
    ArrayList<Color> c;
    ArrayList<Integer> in;
    int y = 0;
    RandomGen gen;
    Color[] co = new Color[4];

    public FlyWeightFactoryTubes(MediatorPanel mp, Point location)
    {
        gen = new RandomGen();
        this.setLayout(null);
        this.mp = mp;
        this.setLocation(new Point(location));
        this.setSize(new Dimension(100, 800));
        this.setVisible(true);
        initLists();
        this.addMouseListener(new UpAction(mp, this));
    }

    public void initLists()
    {
        c = new ArrayList<Color>();
        in = new ArrayList<Integer>();
        in.add(0);
        in.add(200);
        in.add(400);
        in.add(600);
        c.add(Color.cyan);
        c.add(Color.pink);
        c.add(Color.white);
        c.add(Color.green);
        for (int i = 0; i < co.length; i++)
        {
            co[i] = c.get(i);
        }
        for (int i = 0; i < c.size(); i++)
        {
            int index = 0;
            do
            {
                index = gen.getInstance().nextInt(4);
            }
            while (index < 0 || index > 3);
            c.set(i, co[index]);
        }
    }

    @Override
    protected void paintComponent(Graphics grphcs)
    {
        super.paintComponent(grphcs);
        Graphics2D s = (Graphics2D) grphcs;
        s.setColor(Color.blue);
        s.drawRect(0, 0, getWidth(), getHeight());
        y = 0;
        for (int i = 0; i < c.size(); i++)
        {
            System.out.println("am desenaat");
            int index = 0;
            do
            {
                index = gen.getInstance().nextInt(4);
            }
            while (index < 0 || index > 3);
            s.setColor(c.get(i));
            s.fillRect(0, in.get(i), getWidth(), 200);
        }
    }
}
