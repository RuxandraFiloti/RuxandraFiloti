/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.awt.BorderLayout;
import java.awt.HeadlessException;
import javax.swing.JFrame;

/**
 *
 * @author casap
 */
public class MyFrame
        extends JFrame
{

    BorderLayout b;
    MediatorPanel mp;

    public MyFrame()
    {
        b = new BorderLayout();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(b);
        this.setSize(1500, 1000);
        this.setLocationRelativeTo(null);
        mp = new MediatorPanel(this);
        this.add(mp);
    }
}
