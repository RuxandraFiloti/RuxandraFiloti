/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import javax.swing.SwingUtilities;

/**
 *
 * @author casap
 */
public class start
{

    static MyFrame frame;

    public static void main(String[] args)
    {
        frame = new MyFrame();
        frame.setVisible(true);
        //frame.pack();
    }
}
