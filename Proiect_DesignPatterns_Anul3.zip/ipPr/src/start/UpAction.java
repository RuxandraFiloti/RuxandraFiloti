/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 *
 * @author casap
 */
public class UpAction
        implements MouseListener
{

    int nrP = 0;
    MediatorPanel mp;
    FlyWeightFactoryTubes fwt;

    public UpAction(MediatorPanel mp, FlyWeightFactoryTubes fwft)
    {
        this.mp = mp;
        this.fwt = fwft;
    }

    @Override
    public void mouseClicked(MouseEvent me)
    {
    }

    @Override
    public void mousePressed(MouseEvent me)
    {
        Point now = new Point(fwt.getLocation());
        System.out.println("presseeed");
        if (nrP == 0)
        {
            Point newP = new Point(now.x, now.y - 30);
            fwt.setLocation(newP);
            nrP = 2;
        }
        else
        {
            nrP = 0;
            Point newP = new Point(now.x, now.y + 30);
            fwt.setLocation(newP);
        }
    }

    @Override
    public void mouseReleased(MouseEvent me)
    {
    }

    @Override
    public void mouseEntered(MouseEvent me)
    {
    }

    @Override
    public void mouseExited(MouseEvent me)
    {
    }
}
