/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package start;

import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author casap
 */
public class FlyWeightFactory
{

    static MediatorPanel mp;
    static int nr = 0;

    public FlyWeightFactory(MediatorPanel mp)
    {
        this.mp = mp;
    }

    public void getTube(Point loc)
    {
        if (nr < 4)
        {
            //System.out.println("ggg " + (new Point(in.get(nr), 70)).toString());
            FlyWeightFactoryTubes tube = new FlyWeightFactoryTubes(mp, loc);
            mp.add(tube);
            nr++;
        }
    }

    public void addToPanel(Point a)
    {
        System.out.println("aaaaa");
        getTube(a);
        //mp.repaint();
    }
}
